# vit-artifact

Persistent encoder-artifact store for ViT-disaggregated vLLM serving.

- **Key**: `mm_hash = h128(normalized URL + lora_name + query_fp)` — same
  key on E and PD via the request-level `uuid` field (vLLM native, no
  engine change for the hash channel).
- **Commit protocol**: CAS chunks + `_SUCCESS` (manifest embedded) —
  single-object flip; atomicity lives in the store base class, backends
  only implement 4 IO primitives.
- **Backends**: `file://` (stdlib, CI) · `oss://` (oss2, lazy) ·
  paimon/holo/igraph are skeleton (`NotImplementedError`) until their
  SDKs land.

## Install

    pip install "vit-artifact[oss]"        # OSS backend
    pip install vit-artifact               # core only (file:// for tests/CI)

## Engine patch (required for on_miss=fail)

    cd <vllm fork> && git apply patches/vllm-v0.17.1_omega-ec-plugin.patch

Three hunks: strict-miss request-level failure (`ECArtifactMissError` +
`scheduler` safe-point finish + `num_embeds` cross-check) and the PD
no-image synthesis hook (`VLLM_VIT_SYNTH`).

## Activate (runtime only — install ≠ activate)

    EXTRA_CMD='--ec-transfer-config {"ec_connector":"ECArtifactConnector","ec_connector_module_path":"vit_artifact.adapters.vllm","ec_role":"ec_producer"}'
    VIT_ARTIFACT_URI=oss://<bucket>/vision_cache
    OSS_ENDPOINT=... OSS_ACCESS_KEY_ID=... OSS_ACCESS_KEY_SECRET=...   # Secret 注入

E side additionally: `--mm-encoder-only --enforce-eager
--no-enable-prefix-caching --max-num-batched-tokens 114688`.
PD side: `ec_role":"ec_consumer"`, `VLLM_VIT_SYNTH=1` (no-image form),
`VIT_ARTIFACT_ON_MISS=fail` (default) — driver passes `uuid =
h128(url)` in every image_url part on BOTH services.

## E store-verify (optional)

    VIT_ARTIFACT_E_VERIFY_STORE=1     # E side only; default off

E normally treats an in-process encoder-cache (L1) hit as final and
never re-checks the store. With this on, every L1 hit point-checks
`_SUCCESS` (one GET per duplicate image); a missing artifact is
re-uploaded from the L1-resident tensor in the background
(`e-verify miss ... resave scheduled` + `persist ... committed`).
Use it when artifacts may be deleted out-of-band.

## Batch barrier (Job1 → Job2)

    vit-artifact wait-ready --uri "$VIT_ARTIFACT_URI" \
      --fingerprint <from E init log> --expect N --timeout 3600

## Dev

    PYTHONPATH=src python3 -m pytest tests/ -q

Design doc: `docs/superpowers/designs/2026-09-08-vit-artifact-plugin-design.md`
