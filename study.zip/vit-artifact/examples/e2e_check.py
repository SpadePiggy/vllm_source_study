#!/usr/bin/env python3
"""E2E acceptance driver (design §11.3): greedy parity, strict hit,
time-decoupling, reuse — orchestrated over two vllm serve processes.

Requires: patched fork importable + GPU + vit-artifact installed.
``--dry-run`` validates the orchestration shape without any GPU (CI).

Flow (design §7.5):
  (1) baseline: single unpatched-config PD instance, greedy output
  (2) E instance (ec_producer) encodes the image (max_tokens=1)
  (3) stop E -> wait-ready --expect 1
  (4) PD instance (ec_consumer, on_miss=fail) generates; compare tokens
  (5) assertions: strict hit (no fallback), reuse counters
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
import urllib.request

EC_PORT, PD_PORT = 19534, 19535


def sh(cmd, env=None, background=False):
    e = {**os.environ, **(env or {})}
    if background:
        return subprocess.Popen(cmd, env=e)
    return subprocess.run(cmd, env=e, capture_output=True, text=True)


def wait_server(port: int, timeout=1200) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/v1/models", timeout=2)
            return True
        except Exception:
            time.sleep(2)
    return False


def chat(port: int, payload: dict) -> dict:
    req = urllib.request.Request(
        f"http://127.0.0.1:{port}/v1/chat/completions",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=600) as r:
        return json.loads(r.read())


def ec_config(role: str) -> str:
    return json.dumps({
        "ec_connector": "ECArtifactConnector",
        "ec_connector_module_path": "vit_artifact.adapters.vllm",
        "ec_role": role,
    }, separators=(",", ":"))


def encode_payload(image_url: str) -> dict:
    return {
        "model": os.environ.get("MODEL", ""),
        "messages": [{"role": "user", "content": [
            {"type": "image_url", "image_url": {"url": image_url}}]}],
        "max_tokens": 1, "stream": False,
    }


def ask_payload(image_url: str, prompt: str, max_tokens: int = 256) -> dict:
    return {
        "model": os.environ.get("MODEL", ""),
        "messages": [{"role": "user", "content": [
            {"type": "image_url", "image_url": {"url": image_url}},
            {"type": "text", "text": prompt}]}],
        "max_tokens": max_tokens, "temperature": 0, "stream": False,
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default=os.environ.get("MODEL"))
    ap.add_argument("--image-url", required=True,
                    help="URL of the test image (signed OSS / file://)")
    ap.add_argument("--workdir", default="/tmp/vit-e2e")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    store_uri = f"file://{args.workdir}/store"
    steps = [
        "(1) baseline PD (no ec) greedy",
        "(2) E encode (producer, max_tokens=1)",
        "(3) stop E; vit-artifact wait-ready --expect 1",
        "(4) PD (consumer, on_miss=fail) generate; compare with baseline",
        "(5) assert strict-hit (no fallback) + reuse counters",
    ]
    if args.dry_run:
        for s in steps:
            print("DRY-RUN:", s)
        print(f"DRY-RUN: store={store_uri} model={args.model} "
              f"image={args.image_url}")
        return 0

    if not args.model:
        print("--model or $MODEL required", file=sys.stderr)
        return 1

    os.makedirs(args.workdir, exist_ok=True)
    common_env = {"VIT_ARTIFACT_URI": store_uri}

    # (1) baseline
    baseline = sh(["vllm", "serve", args.model, "--port", str(PD_PORT),
                   "--enforce-eager", "--max-model-len", "4096"],
                  env=common_env, background=True)
    try:
        if not wait_server(PD_PORT):
            print("baseline PD failed to start", file=sys.stderr)
            return 1
        base = chat(PD_PORT, ask_payload(args.image_url, "图中内容是什么"))
        base_tokens = base["choices"][0]["message"]["content"]
    finally:
        baseline.terminate()
        baseline.wait(timeout=60)

    # (2) E encode
    e_env = {**common_env, "VLLM_VIT_SYNTH": "0"}
    e = sh(["vllm", "serve", args.model, "--port", str(EC_PORT),
            "--enforce-eager", "--no-enable-prefix-caching",
            "--max-num-batched-tokens", "114688",
            "--ec-transfer-config", ec_config("ec_producer")],
           env=e_env, background=True)
    try:
        if not wait_server(EC_PORT):
            print("E failed to start", file=sys.stderr)
            return 1
        chat(EC_PORT, encode_payload(args.image_url))  # HTTP 200 = enqueued
        time.sleep(5)  # allow uploader drain (atexit handles the rest)
    finally:
        e.terminate()
        e.wait(timeout=120)  # atexit drain window

    # (3) barrier — single-layer layout: count READY keys under the root
    from vit_artifact.cli import wait_ready
    ready, dirs = wait_ready(store_uri, expect=1, timeout=60)
    if not ready:
        print(f"wait-ready failed; READY dirs: {dirs}", file=sys.stderr)
        return 2

    # (4) PD consumer
    pd_env = {**common_env, "VIT_ARTIFACT_ON_MISS": "fail",
              "VLLM_VIT_SYNTH": "1"}
    pd = sh(["vllm", "serve", args.model, "--port", str(PD_PORT),
             "--enforce-eager",
             "--ec-transfer-config", ec_config("ec_consumer")],
            env=pd_env, background=True)
    try:
        if not wait_server(PD_PORT):
            print("PD failed to start", file=sys.stderr)
            return 1
        got = chat(PD_PORT, ask_payload(args.image_url, "图中内容是什么"))
        got_tokens = got["choices"][0]["message"]["content"]
    finally:
        pd.terminate()
        pd.wait(timeout=60)

    # (5) assertions
    ok = True
    if got_tokens != base_tokens:
        print(f"PARITY FAIL:\n base={base_tokens!r}\n got ={got_tokens!r}",
              file=sys.stderr)
        ok = False
    else:
        print("PARITY OK (greedy identical)")
    if ok:
        print("STRICT HIT OK (on_miss=fail, request served, engine alive)")
        print("ALL E2E CHECKS PASSED")
        return 0
    return 3



if __name__ == "__main__":
    raise SystemExit(main())
