#!/bin/bash
# E/PD disagg PoC (design 7.5). Env: MODEL, IMAGE_URL, WORKDIR.
set -euo pipefail
cd "$(dirname "$0")/.."
export MODEL="${MODEL:-Qwen/Qwen2.5-VL-3B-Instruct}"
export IMAGE_URL="${IMAGE_URL:?need a reachable image URL (signed OSS / file://)}"
export WORKDIR="${WORKDIR:-/tmp/vit-e2e}"
python3 examples/e2e_check.py --model "$MODEL" --image-url "$IMAGE_URL" \
  --workdir "$WORKDIR" "$@"
