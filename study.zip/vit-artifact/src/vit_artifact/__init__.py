"""vit-artifact: persistent encoder artifact store for ViT disaggregation."""
from vit_artifact.config import (
    DEFAULT_KEY_DTYPE,
    StoreConfig,
    cache_key,
    compute_fingerprint,
    mm_hash_from_url,
    normalize_dtype,
    normalize_model_identity,
    normalize_url,
)
from vit_artifact.errors import (
    ArtifactCorruptError,
    ArtifactFingerprintMismatchError,
    ArtifactMissError,
    ArtifactStoreError,
)

__all__ = [
    "DEFAULT_KEY_DTYPE",
    "ArtifactCorruptError",
    "ArtifactFingerprintMismatchError",
    "ArtifactMissError",
    "ArtifactStoreError",
    "StoreConfig",
    "cache_key",
    "compute_fingerprint",
    "mm_hash_from_url",
    "normalize_dtype",
    "normalize_model_identity",
    "normalize_url",
    "open_store",
]


def open_store(uri: str, model: str = "", dtype: str = ""):
    """Dispatch a store by URI scheme (design 4.1 backend family).

    Single-layer key layout (0.2): {root}/{cache_key}/ — the key carries
    model+URL+dtype; model/dtype are also stored on the instance for
    manifest-level defensive re-assertion on every read.

    file://  -> LocalStore (stdlib, CI)
    oss://   -> OSSStore   (requires vit-artifact[oss], lazy import)
    paimon/holo/igraph:// -> NotImplementedError (skeleton, design L6)
    """
    if uri.startswith("file://"):
        from vit_artifact.backends.local import LocalStore
        return LocalStore(uri[len("file://"):], model, dtype)
    if uri.startswith("oss://"):
        try:
            from vit_artifact.backends.oss import OSSStore
            return OSSStore(uri, model, dtype)
        except ModuleNotFoundError:
            raise ValueError(
                "oss:// configured but oss2 is not installed: "
                "pip install vit-artifact[oss]"
            ) from None
    for scheme in ("paimon", "holo", "igraph"):
        if uri.startswith(f"{scheme}://"):
            raise NotImplementedError(
                f"{scheme}:// backend is skeleton-only until its SDK lands (design L6)")
    raise ValueError(f"unsupported store URI scheme: {uri!r}")
