"""vLLM adapter subpackage.

``ECArtifactConnector`` imports vllm at module load — importing it pulls
the whole vllm package (by design: this subpackage only runs inside a
vllm process). The factory loads it via ``ec_connector_module_path``.

``uploader``/``worker_io`` are torch-only and importable without vllm
for testing.

``ECArtifactConnector`` is re-exported here through a module-level
``__getattr__`` (PEP 562) so that ``vit_artifact.adapters.vllm`` works
as a factory module path — without importing vllm at package-import
time, which keeps torch-only test environments working.
"""
from __future__ import annotations

__all__ = ["ECArtifactConnector"]


def __getattr__(name: str):
    # Lazy re-export: only resolved when the attribute is actually
    # requested (i.e. inside a vllm process via ec_connector_module_path).
    if name == "ECArtifactConnector":
        from vit_artifact.adapters.vllm.artifact_connector import (
            ECArtifactConnector,
        )
        return ECArtifactConnector
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
