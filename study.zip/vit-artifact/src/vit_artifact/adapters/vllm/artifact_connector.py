"""ECArtifactConnector: vit-artifact adapter for vLLM ECConnectorBase.

Design §5.0/§7.1.1 role gates: producer never queries the store
(has=False), consumer carries the full hit path. This module is the
ONLY place in the package that imports vllm; loaded via
ec_connector_module_path.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field

from vllm.distributed.ec_transfer.ec_connector.base import (
    ECArtifactMissError,
    ECConnectorBase,
    ECConnectorMetadata,
    ECConnectorRole,
)

from vit_artifact import ArtifactCorruptError, open_store
from vit_artifact.config import (
    StoreConfig,
    normalize_dtype,
    normalize_model_identity,
)

logger = logging.getLogger(__name__)


@dataclass
class ECArtifactConnectorMetadata(ECConnectorMetadata):
    # (mm_hash, num_tokens, manifest) triples; must stay picklable —
    # scheduler→worker handoff (design 5.0).
    items: list = field(default_factory=list)
    # E store-verify mode (VIT_ARTIFACT_E_VERIFY_STORE=1): mm_hash ->
    # grid (list|None) of L1-hit items whose artifact is missing from
    # the store; the worker re-uploads the L1-resident tensor.
    resave: dict = field(default_factory=dict)


def _grid_from_mm_feature(mm_feature) -> tuple | None:
    """Best-effort image_grid_thw from the scheduler-side processor
    output (MultiModalKwargsItem is a dict; the field elem's .data is
    the tensor — same shape the fork's gpu_model_runner reads), so a
    re-uploaded manifest keeps its plan-C grid."""
    item = getattr(mm_feature, "data", None)
    if item is None:
        return None
    try:
        elem = item.get("image_grid_thw")
        grid = getattr(elem, "data", elem)
        if grid is None:
            return None
        return tuple(int(x) for x in
                     (grid.tolist() if hasattr(grid, "tolist") else grid))
    except Exception:  # noqa: BLE001 — grid is best-effort metadata
        return None


class ECArtifactConnector(ECConnectorBase):
    def __init__(self, vllm_config, role: ECConnectorRole):
        super().__init__(vllm_config=vllm_config, role=role)
        extra = (vllm_config.ec_transfer_config.ec_connector_extra_config or {})
        cfg = StoreConfig.from_env(extra)
        self._on_miss = cfg.on_miss
        self._memo_ttl = cfg.memo_ttl
        self._e_verify_store = cfg.e_verify_store
        # E store-verify mode: mm_hash -> grid of L1-hit items whose
        # artifact is missing from the store (drained by
        # build_connector_meta, re-uploaded by the worker).
        self._resave: dict = {}

        # Single-layer key: h128(model, URL, dtype) via cache_key() per item.
        # Key shrinks, defense doesn't: the manifest re-asserts model+dtype
        # so a key collision degrades to a loud miss, never a silent hit.
        self._model_identity = normalize_model_identity(
            vllm_config.model_config.model)
        self._dtype = normalize_dtype(vllm_config.model_config.dtype)
        # Worker-side load destination: the engine mixin never passes a
        # device to start_load_caches, so the consumer records it from
        # device_config; worker_io._resolve_device falls back to
        # torch.cuda.current_device() when this is absent.
        device_cfg = getattr(vllm_config, "device_config", None)
        self.device = str(getattr(device_cfg, "device", "")) or None
        logger.info(
            "vit-artifact store model=%s dtype=%s device=%s "
            "key=cached_h128(model,url,dtype) e_verify_store=%s",
            self._model_identity, self._dtype, self.device or "auto",
            self._e_verify_store)

        # fail-mode needs the patched base module (design L5): refuse to
        # start rather than dying at the first strict miss.
        if self._on_miss == "fail" and "ECArtifactMissError" not in dir(
                __import__(__name__, fromlist=["ECArtifactMissError"])):
            raise RuntimeError(
                "on_miss=fail requires the vit-artifact engine patch "
                "(ECArtifactMissError missing from ec_connector.base)")

        self._store = open_store(
            cfg.uri, model=self._model_identity, dtype=self._dtype)
        # mm_hash -> (hit, expires_at, manifest)
        self._memo: dict = {}
        # mm_hash -> (num_tokens, manifest)
        self._pending: dict = {}
        self._uploader = None
        if self.is_producer:
            from vit_artifact.adapters.vllm.uploader import Uploader
            self._uploader = Uploader(
                self._store,
                concurrency=cfg.upload_concurrency,
                queue_size=cfg.upload_queue_size,
                model=self._model_identity, dtype=self._dtype,
                verify_store=cfg.e_verify_store)

    # ---------------- scheduler side ----------------
    def note_l1_hit(self, request, index: int) -> None:
        """E store-verify mode (VIT_ARTIFACT_E_VERIFY_STORE=1): an
        engine-side L1 encoder-cache hit only stands when the artifact
        also exists in the external store — point-check _SUCCESS; on
        miss, schedule a re-upload of the L1-resident tensor via
        connector metadata (self-heals out-of-band store deletions).
        Cost: one store GET per L1-hit item, only when enabled."""
        if not (self.is_producer and self._e_verify_store):
            return
        mm_hash = request.mm_features[index].identifier
        if self._store_pointcheck(mm_hash):
            return
        grid = _grid_from_mm_feature(request.mm_features[index])
        if mm_hash in self._resave:
            self._resave[mm_hash] = grid or self._resave[mm_hash]
            return
        self._resave[mm_hash] = grid
        logger.info("vit-artifact e-verify miss mm_hash=%s — resave "
                    "scheduled from L1 tensor", mm_hash)

    def _store_pointcheck(self, identifier: str) -> bool:
        try:
            return self._store.get_ready_manifest(identifier) is not None
        except Exception as e:  # noqa: BLE001 — verify degrades to missing
            logger.warning("vit-artifact e-verify point-check error for "
                           "%s: %r", identifier, e)
            return False

    def has_cache_item(self, identifier: str,
                       num_embeds: int | None = None) -> bool:
        if not self.is_consumer:
            return False  # producer gate (design 7.1.1)
        now = time.monotonic()
        cached = self._memo.get(identifier)
        if cached is not None and cached[1] > now:
            if cached[0] and num_embeds is not None \
                    and cached[2] is not None \
                    and cached[2].num_mm_tokens != num_embeds:
                return self._miss(identifier, "MISS_TOKEN_MISMATCH")
            return cached[0]
        try:
            manifest = self._store.get_ready_manifest(identifier)
        except ArtifactCorruptError as e:
            logger.warning("vit-artifact corrupt for %s: %s", identifier, e)
            return self._miss(identifier, f"CORRUPT:{e}")
        if manifest is None:
            return self._miss(identifier, "MISS_NO_MARKER")
        if num_embeds is not None and manifest.num_mm_tokens != num_embeds:
            return self._miss(identifier, "MISS_TOKEN_MISMATCH")
        self._memo[identifier] = (True, now + self._memo_ttl, manifest)
        return True

    def _miss(self, identifier: str, reason: str) -> bool:
        self._memo[identifier] = (False, time.monotonic() + self._memo_ttl, None)
        if self._on_miss == "fail":
            raise ECArtifactMissError(reason)
        return False

    def update_state_after_alloc(self, request, index) -> None:
        if not self.is_consumer:
            return
        mm_hash = request.mm_features[index].identifier
        cached = self._memo.get(mm_hash)
        manifest = cached[2] if cached else None
        if manifest is None:
            return
        self._pending[mm_hash] = (manifest.num_mm_tokens, manifest)

    def build_connector_meta(self, scheduler_output):
        # items must be (mm_hash, num_tokens, manifest) TRIPLES — the
        # documented contract worker_io unpacks; _pending.items() yields
        # (key, value) pairs (the 0.2.3 arity bug crashed PD's first
        # external load with "not enough values to unpack").
        meta = ECArtifactConnectorMetadata(
            items=[(h, n, m) for h, (n, m) in self._pending.items()],
            resave=dict(self._resave))
        self._pending.clear()
        self._resave.clear()
        return meta

    # ---------------- worker side ----------------
    def start_load_caches(self, encoder_cache, **kwargs) -> None:
        from vit_artifact.adapters.vllm.worker_io import load_into_encoder_cache
        load_into_encoder_cache(self, encoder_cache, **kwargs)

    def save_caches(self, encoder_cache, mm_hash, **kwargs) -> None:
        if not self.is_producer:
            return
        try:
            from vllm.distributed import get_tensor_model_parallel_rank
        except ImportError:  # no distributed init (tests): rank 0
            pass
        else:
            if get_tensor_model_parallel_rank() != 0:
                return
        # grid_thw arrives via kwargs from the engine-side patch
        # (gpu_model_runner passes item["image_grid_thw"]) so PD's synth
        # placeholder can be forward-constructed at the exact same grid.
        grid_thw = kwargs.get("grid_thw")
        self._uploader.enqueue(encoder_cache, mm_hash, grid_thw=grid_thw)

    def request_finished(self, request) -> tuple:
        return False, None  # A1: snapshot-at-enqueue, nothing to hold

    def shutdown(self) -> None:
        if self._uploader is not None:
            self._uploader.drain(timeout=600.0)
