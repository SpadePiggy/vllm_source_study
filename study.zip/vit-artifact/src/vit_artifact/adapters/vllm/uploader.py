"""Async producer uploader: D2H snapshot, bounded queue, CAS commit.

Design §3.2 (A1-A5): enqueue() snapshots the tensor to CPU bytes and
returns immediately — the GPU never waits for the store. Worker threads
own the full attempt→chunk→commit protocol.
"""
from __future__ import annotations

import hashlib
import logging
import queue
import threading
import time

import torch

from vit_artifact.manifest import ChunkMeta, Manifest, TensorMeta

logger = logging.getLogger(__name__)

_DRAIN_TIMEOUT = 600.0  # module constant (design 6.1)


def tensor_to_meta_and_bytes(t: torch.Tensor) -> tuple:
    dtype = str(t.dtype).replace("torch.", "")
    meta = TensorMeta(dtype=dtype, hidden_size=t.shape[-1], num_mm_tokens=t.shape[0])
    cpu = t.detach().to("cpu", copy=True).contiguous()
    if cpu.dtype == torch.bfloat16:
        raw = cpu.view(torch.uint8).numpy().tobytes()
    else:
        raw = cpu.numpy().tobytes()
    return meta, raw


class Uploader:
    def __init__(self, store, concurrency: int = 4, queue_size: int = 64,
                 model: str = "", dtype: str = "", verify_store: bool = False):
        # model/dtype: manifest defensive identity — mirrors the store's
        # so the read-side check (atomic.get_ready_manifest) matches what
        # the write side recorded.
        # verify_store: E store-verify mode — do not trust the in-process
        # _persisted set; _persist_one's store.has() point-check decides
        # (re-uploads artifacts deleted out-of-band).
        self._store = store
        self._verify_store = verify_store
        self._model = model
        self._dtype = dtype
        self._queue: queue.Queue = queue.Queue(maxsize=queue_size)
        self._persisted: set = set()
        self._inflight: set = set()
        self._inflight_lock = threading.Lock()
        self._drained = False
        self.counters = {"committed": 0, "reused": 0, "skipped": 0, "failed": 0}
        self._threads = [
            threading.Thread(target=self._worker,
                             name=f"vit-artifact-upl-{i}", daemon=True)
            for i in range(concurrency)
        ]
        for t in self._threads:
            t.start()
        import atexit
        atexit.register(lambda: self.drain(timeout=_DRAIN_TIMEOUT))

    def enqueue(self, encoder_cache: dict, mm_hash: str,
                grid_thw: tuple | None = None) -> None:
        if mm_hash in self._persisted and not self._verify_store:
            self.counters["reused"] += 1
            return
        with self._inflight_lock:
            if mm_hash in self._inflight:
                return  # single-flight (A4)
            self._inflight.add(mm_hash)
        tensor = encoder_cache.get(mm_hash)
        if tensor is None:
            with self._inflight_lock:
                self._inflight.discard(mm_hash)
            return
        meta, raw = tensor_to_meta_and_bytes(tensor)  # D2H snapshot (A1)
        # grid is plain ints — cheap to carry alongside the payload
        grid = tuple(int(x) for x in grid_thw) if grid_thw is not None else None
        self._queue.put((mm_hash, meta, raw, grid))  # bounded; full = backpressure

    def _worker(self) -> None:
        while True:
            item = self._queue.get()
            if item is None:
                self._queue.task_done()  # sentinel: balance the put, then exit
                return
            mm_hash, meta, raw, grid = item
            try:
                self._persist_one(mm_hash, meta, raw, grid)
            except Exception as e:  # noqa: BLE001 — never kill the engine (A3)
                self.counters["failed"] += 1
                logger.warning("vit-artifact persist failed mm_hash=%s err=%r",
                               mm_hash, e)
            finally:
                with self._inflight_lock:
                    self._inflight.discard(mm_hash)
                self._queue.task_done()

    def _persist_one(self, mm_hash: str, meta: TensorMeta, raw: bytes,
                     grid_thw: tuple | None = None) -> None:
        if self._store.has(mm_hash):
            self.counters["skipped"] += 1
            logger.info("vit-artifact persist mm_hash=%s result=skipped "
                        "(store already has artifact)", mm_hash)
            self._persisted.add(mm_hash)
            return
        started = time.monotonic()
        attempt_id = self._store.begin_attempt(
            {"mm_hash": mm_hash, "tensor_meta": meta})
        self._store.write_chunk({"attempt_id": attempt_id, "chunk_id": 0}, raw)
        checksum = "sha256:" + hashlib.sha256(raw).hexdigest()
        manifest = Manifest(
            mm_hash=mm_hash, model=self._model,
            dtype=meta.dtype, hidden_size=meta.hidden_size,
            num_mm_tokens=meta.num_mm_tokens, attempt_id=attempt_id,
            grid_thw=grid_thw,
            created_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            chunks=(ChunkMeta(
                0, meta.num_mm_tokens, len(raw), checksum,
                f"{self._store._dir(mm_hash)}/chunks/{checksum[7:]}"),))
        self._store.commit(manifest)
        self._persisted.add(mm_hash)
        self.counters["committed"] += 1
        logger.info(
            "vit-artifact persist mm_hash=%s result=committed bytes=%d "
            "seconds=%.3f", mm_hash, len(raw), time.monotonic() - started)

    def drain(self, timeout: float = _DRAIN_TIMEOUT) -> bool:
        if self._drained:
            return True
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline and self._queue.unfinished_tasks:
            time.sleep(0.05)
        for _ in self._threads:
            self._queue.put(None)
        for t in self._threads:
            t.join(timeout=max(0.0, deadline - time.monotonic()))
        ok = self._queue.unfinished_tasks == 0
        if ok:
            self._drained = True
        return ok
