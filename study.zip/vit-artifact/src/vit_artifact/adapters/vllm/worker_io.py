"""Consumer-side cache loading: CAS fetch + checksum + inject.

Design §3.4 / §7.4 stage ②. Crash-level on corruption is by design:
local encoding was already skipped, no fallback remains (design 5.3).
"""
from __future__ import annotations

import hashlib
import logging
from concurrent.futures import ThreadPoolExecutor

import torch

logger = logging.getLogger(__name__)

_LOAD_THREADS = 8  # module constant (design 6.1)

_TORCH_DTYPES = {"bfloat16": torch.bfloat16, "float16": torch.float16,
                 "float32": torch.float32}


def _load_one(store, encoder_cache: dict, mm_hash: str, manifest,
              device: str) -> None:
    chunk = manifest.chunks[0]  # v1: single chunk (design 4.4)
    raw = store.open_chunk(chunk.locator)
    actual = "sha256:" + hashlib.sha256(raw).hexdigest()
    if actual != chunk.checksum:
        raise RuntimeError(
            f"chunk checksum mismatch for {mm_hash}: expected {chunk.checksum}, "
            f"got {actual} — silent storage corruption")
    dtype = _TORCH_DTYPES[manifest.dtype]
    t = torch.frombuffer(bytearray(raw), dtype=dtype).reshape(
        manifest.num_mm_tokens, manifest.hidden_size)
    encoder_cache[mm_hash] = t.to(device)
    logger.info("vit-artifact load mm_hash=%s bytes=%d", mm_hash, len(raw))


def _resolve_device(connector, kwargs) -> str:
    """The tensor's destination device, resolved without engine support.

    The engine's mixin calls start_load_caches(encoder_cache, **kwargs)
    WITHOUT any device kwarg, so the old getattr fallback silently put
    every loaded embedding on CPU — on GPU deployments the forward pass
    then crashed on a cross-device tensor (the "PD pod dies on first
    hit" bug). Resolution order:
    1. explicit connector.device (set by __init__ from device_config)
    2. engine-passed kwargs["device"] (none today, kept for future)
    3. torch.cuda.current_device() inside the worker process — the
       correct per-TP-rank GPU after distributed init
    4. "cpu" only when CUDA is genuinely unavailable
    """
    device = getattr(connector, "device", None) or kwargs.get("device")
    if device:
        return str(device)
    try:
        if torch.cuda.is_available() and torch.cuda.is_initialized():
            return f"cuda:{torch.cuda.current_device()}"
    except Exception as e:  # noqa: BLE001 — device probe must never kill the load path
        logger.debug("cuda device probe failed, falling back to cpu: %r", e)
    return "cpu"


def load_into_encoder_cache(connector, encoder_cache: dict, **kwargs) -> None:
    meta = connector._get_connector_metadata()
    items = getattr(meta, "items", None) or []
    device = _resolve_device(connector, kwargs)
    todo = [(h, m) for h, _n, m in items if h not in encoder_cache]
    if not todo:
        return
    store = connector._store
    if len(todo) == 1:
        _load_one(store, encoder_cache, todo[0][0], todo[0][1], device)
        return
    with ThreadPoolExecutor(max_workers=_LOAD_THREADS) as pool:
        futures = [pool.submit(_load_one, store, encoder_cache, h, m, device)
                   for h, m in todo]
        for f in futures:
            f.result()  # propagate first failure
