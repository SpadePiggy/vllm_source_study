"""EncoderArtifactStore base class: template-method commit protocol.

Design §4.1/§4.3: the base class owns the atomicity protocol — attempt
bookkeeping, CAS chunk keys, cross-checked ``_SUCCESS`` flip. Backends
override only the 4 primitive IO hooks, so no backend can get the
protocol wrong.
"""
from __future__ import annotations

import hashlib
import json
import uuid
from abc import ABC, abstractmethod
from dataclasses import asdict

from vit_artifact.errors import ArtifactCorruptError, ArtifactFingerprintMismatchError
from vit_artifact.manifest import FORMAT_VERSION, Manifest, TensorMeta

_SUCCESS = "_SUCCESS"


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _canonical_json(obj) -> bytes:
    """Single serialization used by both write and read paths so the
    digest check never fights key ordering."""
    return json.dumps(obj, separators=(",", ":"), sort_keys=True).encode("utf-8")


class EncoderArtifactStore(ABC):
    """Interface aligned with 方案.md §10.1; the only protocol implementation.

    Key layout (design 4.3):
        {root}/{mm_hash}/chunks/{chunk_digest}
        {root}/{mm_hash}/_SUCCESS   (single mutable object)
    """

    def __init__(self, root: str, model: str = "", dtype: str = ""):
        # model/dtype are the manifest-level defensive identity: the key
        # already carries them; these re-assert them on every read so a
        # collision degrades to a loud miss instead of a silent hit.
        self.root = root.rstrip("/")
        self.model = model
        self.dtype = dtype
        # attempt_id -> {"mm_hash": str, "chunks": {chunk_id: (length, checksum_hex)}}
        self._attempts: dict[str, dict] = {}

    # ---------- key layout ----------
    def _dir(self, mm_hash: str) -> str:
        # single-layer layout (0.2): the key IS the identity
        return f"{self.root}/{mm_hash}"

    def _success_key(self, mm_hash: str) -> str:
        return f"{self._dir(mm_hash)}/{_SUCCESS}"

    # ---------- public protocol (方案.md §10.1) ----------
    def has(self, mm_hash: str) -> bool:
        return self.get_ready_manifest(mm_hash) is not None

    def begin_attempt(self, metadata: dict) -> str:
        attempt_id = uuid.uuid4().hex[:16]
        meta: TensorMeta = metadata["tensor_meta"]
        _ = meta.expected_bytes  # fail fast on unsupported dtype
        self._attempts[attempt_id] = {"mm_hash": metadata["mm_hash"], "chunks": {}}
        return attempt_id

    def write_chunk(self, chunk_meta: dict, tensor_bytes: bytes) -> None:
        attempt_id = chunk_meta["attempt_id"]
        chunk_id = chunk_meta["chunk_id"]
        state = self._attempts.get(attempt_id)
        if state is None:
            raise ValueError(f"unknown attempt {attempt_id}")
        checksum_hex = _sha256_hex(tensor_bytes)
        state["chunks"][chunk_id] = (len(tensor_bytes), checksum_hex)
        # CAS key: content address — idempotent re-PUT is free (design 4.3)
        self._put(f"{self._dir(state['mm_hash'])}/chunks/{checksum_hex}", tensor_bytes)

    def commit(self, manifest: Manifest) -> None:
        state = self._attempts.get(manifest.attempt_id)
        if state is None:
            raise ValueError(f"unknown attempt {manifest.attempt_id}")
        if state["mm_hash"] != manifest.mm_hash:
            raise ValueError("attempt/mm_hash mismatch")
        # Cross-check every manifest chunk against what was actually written:
        # the commit right belongs to the base class, callers cannot forge it.
        for c in manifest.chunks:
            written = state["chunks"].get(c.chunk_id)
            if written is None:
                raise ValueError(f"manifest references unwritten chunk {c.chunk_id}")
            length, checksum_hex = written
            if c.length != length or c.checksum != f"sha256:{checksum_hex}":
                raise ValueError(f"chunk {c.chunk_id} meta diverges from written bytes")
        if set(state["chunks"]) != {c.chunk_id for c in manifest.chunks}:
            raise ValueError("written chunks and manifest chunks differ")
        manifest.validate(current_format_version=FORMAT_VERSION)

        manifest_dict = asdict(manifest)
        payload = _canonical_json({
            "digest": f"sha256:{_sha256_hex(_canonical_json(manifest_dict))}",
            "attempt_id": manifest.attempt_id,
            "manifest": manifest_dict,
        })
        self._put(self._success_key(manifest.mm_hash), payload)
        self._attempts.pop(manifest.attempt_id, None)

    def get_ready_manifest(self, mm_hash: str, *,
                           check_identity: bool = True) -> Manifest | None:
        """Parse + validate ``_SUCCESS``.

        ``check_identity=False`` skips the model/dtype defense — for
        callers that only need artifact METADATA (e.g. the PD synth
        placeholder's grid lookup, which runs in the frontend process
        that has no engine config). Safe: a cross-identity grid at
        worst yields a wrong-size placeholder, which the consumer-side
        num_embeds cross-check (gate 4) turns into a loud strict miss —
        the embedding itself still only ever flows through the fully
        defended has_cache_item/load path.
        """
        try:
            payload = self._get(self._success_key(mm_hash))
        except KeyError:
            return None
        try:
            doc = json.loads(payload)
            digest = doc["digest"]
            inner = doc["manifest"]
        except (json.JSONDecodeError, KeyError, TypeError) as e:
            raise ArtifactCorruptError(f"_SUCCESS unparsable: {e}") from e
        if not isinstance(inner, dict):
            raise ArtifactCorruptError("_SUCCESS.manifest must be an object")
        # digest self-check: stored digest must match the embedded manifest
        if digest != f"sha256:{_sha256_hex(_canonical_json(inner))}":
            raise ArtifactCorruptError("_SUCCESS digest does not match embedded manifest")
        try:
            manifest = Manifest.from_json_bytes(_canonical_json(inner))
        except ValueError as e:
            raise ArtifactCorruptError(f"embedded manifest invalid: {e}") from e
        if check_identity and (
                manifest.model != self.model or manifest.dtype != self.dtype):
            raise ArtifactFingerprintMismatchError(
                f"manifest model={manifest.model} dtype={manifest.dtype} "
                f"!= local model={self.model} dtype={self.dtype} — key "
                f"collision or cross-config write; refusing to load")
        return manifest

    def open_chunk(self, locator: str) -> bytes:
        return self._get(locator)

    def expire(self, mm_hash: str, version: str | None = None) -> None:
        if version is not None:
            try:
                doc = json.loads(self._get(self._success_key(mm_hash)))
            except KeyError:
                return
            except (json.JSONDecodeError, TypeError):
                return  # corrupted marker: nothing safe to compare, no-op
            if doc.get("digest") != version:
                return  # never delete a concurrent writer's version (铁律 ⑤)
        self._delete(self._success_key(mm_hash))

    # ---------- primitive hooks (backends override; design 4.1) ----------
    @abstractmethod
    def _put(self, key: str, data: bytes) -> None: ...

    @abstractmethod
    def _get(self, key: str) -> bytes:
        """Raise KeyError when the object does not exist."""

    @abstractmethod
    def _delete(self, key: str) -> None: ...

    @abstractmethod
    def _list_prefix(self, prefix: str) -> list[str]:
        """Return full store keys (same namespace as _put/_get, root
        prefix included) beginning with ``prefix``."""
