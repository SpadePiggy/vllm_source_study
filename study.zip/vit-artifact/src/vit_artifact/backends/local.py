"""file:// backend: POSIX tmp+rename atomic writes (CI / single-host).

Design §4.1: LocalStore provides single-object atomicity via
``tempfile.mkstemp`` in the destination directory + ``os.replace``.
"""
from __future__ import annotations

import os
import tempfile
from pathlib import Path

from vit_artifact.atomic import EncoderArtifactStore


class LocalStore(EncoderArtifactStore):
    def __init__(self, local_root: str, model: str = "", dtype: str = ""):
        # resolve() normalizes symlinked prefixes (e.g. /var -> /private/var
        # on macOS) so self.root — which participates in CAS locator keys —
        # is canonical regardless of how the caller spelled the path.
        self._fs_root = Path(local_root).resolve()
        self._fs_root.mkdir(parents=True, exist_ok=True)
        super().__init__(str(self._fs_root), model, dtype)

    def _path(self, key: str) -> Path:
        root = self._fs_root.resolve()
        candidate = Path(key)
        p = candidate if candidate.is_absolute() else root / candidate
        p = p.resolve()
        if not str(p).startswith(str(root)):
            raise ValueError(f"key escapes local root: {key}")
        return p

    def _put(self, key: str, data: bytes) -> None:
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=p.parent)
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(data)
            os.replace(tmp, p)  # atomic (design 4.1)
        except BaseException:
            if os.path.exists(tmp):
                os.remove(tmp)
            raise

    def _get(self, key: str) -> bytes:
        p = self._path(key)
        if not p.is_file():
            raise KeyError(key)
        return p.read_bytes()

    def _delete(self, key: str) -> None:
        try:
            self._path(key).unlink()
        except FileNotFoundError:
            pass

    def _list_prefix(self, prefix: str) -> list[str]:
        # Keys are full store keys (same namespace as _put/_get), i.e.
        # including the root prefix — matching OSSStore's ObjectIterator keys.
        base = self._path(prefix)
        if base.is_dir():
            prefix_dir = prefix.rstrip("/") + "/"
            return sorted(prefix_dir + str(p.relative_to(base))
                          for p in base.rglob("*") if p.is_file())
        if base.is_file():
            return [prefix.rstrip("/")]
        return []
