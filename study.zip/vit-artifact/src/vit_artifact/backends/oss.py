"""oss:// backend: oss2 object API, lazy import, env credentials.

Design §4.1/§7.2.1: credentials reuse the vllm.multimodal.ossutils
convention (OSS_ENDPOINT / OSS_ACCESS_KEY_ID / OSS_ACCESS_KEY_SECRET /
OSS_SESSION_TOKEN); oss2 is imported only when oss:// is configured.
"""
from __future__ import annotations

import os

from vit_artifact.atomic import EncoderArtifactStore


def _build_bucket(store: OSSStore):
    import oss2
    endpoint = os.getenv("OSS_ENDPOINT")
    if not endpoint:
        raise ValueError("OSS_ENDPOINT is not set (vllm.multimodal.ossutils convention)")
    ak = os.getenv("OSS_ACCESS_KEY_ID")
    sk = os.getenv("OSS_ACCESS_KEY_SECRET")
    if not ak or not sk:
        raise ValueError("OSS_ACCESS_KEY_ID / OSS_ACCESS_KEY_SECRET are not set")
    auth = oss2.Auth(ak, sk)
    return oss2.Bucket(auth, endpoint, store._bucket_name, connect_timeout=100)


class OSSStore(EncoderArtifactStore):
    def __init__(self, uri: str, model: str = "", dtype: str = ""):
        import oss2
        from oss2 import ObjectIterator
        self._oss2 = oss2
        self._ObjectIterator = ObjectIterator
        rest = uri[len("oss://"):]
        bucket_name, _, namespace = rest.partition("/")
        if not bucket_name or not namespace:
            raise ValueError(f"oss URI must be oss://<bucket>/<namespace>, got {uri!r}")
        self._bucket_name = bucket_name
        self._bucket = _build_bucket(self)
        super().__init__(namespace.rstrip("/"), model, dtype)

    def _put(self, key, data):
        self._bucket.put_object(key, data)

    def _get(self, key):
        try:
            return self._bucket.get_object(key).read()
        except self._oss2.exceptions.NotFound:
            raise KeyError(key) from None

    def _delete(self, key):
        self._bucket.delete_object(key)

    def _list_prefix(self, prefix):
        return [o.key for o in self._ObjectIterator(self._bucket, prefix=prefix)]
