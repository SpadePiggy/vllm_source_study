"""vit-artifact CLI: wait-ready batch barrier (design §3.3).

Scans {root}/ for mm_hash dirs containing _SUCCESS (single-layer key
layout, 0.2). Precision requires the E service to have exited (unique
writer gone) — the offline flow guarantees this (design §7.5).
"""
from __future__ import annotations

import argparse
import sys
import time

_SUCCESS = "_SUCCESS"


def _ready_dirs(store) -> list[str]:
    prefix = f"{store.root}/"
    ready = set()
    for key in store._list_prefix(prefix):
        rel = key[len(prefix):]
        if rel.endswith(_SUCCESS):
            ready.add(rel[: -len(_SUCCESS) - 1])
    return sorted(ready)


def wait_ready(uri: str, expect: int, timeout: float,
               interval: float = 2.0) -> tuple[bool, list[str]]:
    from vit_artifact import open_store
    store = open_store(uri)
    deadline = time.monotonic() + timeout
    dirs: list[str] = []
    while True:
        dirs = _ready_dirs(store)
        if len(dirs) >= expect:
            return True, dirs
        if time.monotonic() >= deadline:
            return False, dirs
        time.sleep(interval)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="vit-artifact")
    sub = parser.add_subparsers(dest="command", required=True)
    wr = sub.add_parser("wait-ready", help="block until N artifacts are READY")
    wr.add_argument("--uri", required=True)
    wr.add_argument("--expect", type=int, required=True)
    wr.add_argument("--timeout", type=float, default=3600.0)
    wr.add_argument("--interval", type=float, default=2.0)
    try:
        args = parser.parse_args(argv)
    except SystemExit:
        return 1
    ready, dirs = wait_ready(args.uri, args.expect, args.timeout,
                             args.interval)
    if ready:
        print(f"wait-ready: {len(dirs)} artifact(s) READY (>= {args.expect})",
              file=sys.stderr)
        return 0
    print(f"wait-ready: TIMEOUT — only {len(dirs)} READY, expected "
          f"{args.expect}. Ready keys: {dirs}", file=sys.stderr)
    return 2
