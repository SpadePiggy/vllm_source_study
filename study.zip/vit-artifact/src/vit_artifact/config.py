"""URL normalization, 128-bit key hashing, fingerprint and store config.

Design: docs/superpowers/designs/2026-09-08-vit-artifact-plugin-design.md
§4.4 (fingerprint), §5.2.2 (URL-hash override), §6.1 (env config).
"""
from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from urllib.parse import urlparse

VALID_ON_MISS = ("fail", "recompute")

_ENV_URI = "VIT_ARTIFACT_URI"
_ENV_ON_MISS = "VIT_ARTIFACT_ON_MISS"
_ENV_UPLOAD_CONCURRENCY = "VIT_ARTIFACT_UPLOAD_CONCURRENCY"
_ENV_UPLOAD_QUEUE_SIZE = "VIT_ARTIFACT_UPLOAD_QUEUE_SIZE"
_ENV_MEMO_TTL = "VIT_ARTIFACT_MEMO_TTL"
_ENV_E_VERIFY_STORE = "VIT_ARTIFACT_E_VERIFY_STORE"


def _env_bool(value) -> bool:
    return str(value).strip().lower() in ("1", "true", "yes", "on")


def normalize_url(url: str, lora_name: str | None = None,
                  query_fp: str | None = None) -> str:
    """Canonicalize a media URL to ``<bucket>/<object-path>``.

    Strips scheme/endpoint/signature query so that re-signed or scheme-
    swapped URLs of the same object normalize to the same key (design
    5.2.2 — the load-bearing invariant of the URL-key decision).
    Non-OSS/http(s) URLs pass through unchanged (fallback image path:
    data:/file: keep the engine's content hash downstream).

    ``lora_name`` / ``query_fp`` are appended in a dedicated suffix so
    they enter the hashed identity (design 8.1/8.2) without colliding
    with the URL core.
    """
    parsed = urlparse(url)
    if parsed.scheme in ("oss", "http", "https") and parsed.path:
        if parsed.scheme == "oss":
            bucket = parsed.netloc
        else:
            host = parsed.hostname or ""
            bucket = host.split(".")[0]
        core = f"{bucket}/{parsed.path.lstrip('/')}"
    else:
        core = url
    suffix = f"|lora={lora_name or ''}|qfp={query_fp or ''}"
    return core + suffix


def mm_hash_from_url(url: str, lora_name: str | None = None,
                     query_fp: str | None = None) -> str:
    """128-bit (32 hex chars) legacy key: h128(normalized URL).

    Kept for backward compatibility with 0.1.x deployments where the
    store layout was {root}/{fingerprint}/{mm_hash}. New code should
    use :func:`cache_key`.
    """
    normalized = normalize_url(url, lora_name=lora_name, query_fp=query_fp)
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:32]


DEFAULT_KEY_DTYPE = "auto"


def cache_key(url: str, model: str, dtype: str = DEFAULT_KEY_DTYPE,
              lora_name: str | None = None,
              query_fp: str | None = None) -> str:
    """Single-layer 128-bit store key: h128(model, URL, dtype).

    The 0.1.x two-layer layout {fingerprint}/{mm_hash} is collapsed into
    one key that carries the fields which actually vary in production:
    normalized model identity, normalized URL, and dtype. revision /
    processor kwargs / limits are constant per deployment and verified
    defensively in the manifest instead (defense stays, key shrinks).
    """
    normalized = normalize_url(url, lora_name=lora_name, query_fp=query_fp)
    identity = (f"{normalize_model_identity(model)}|{normalize_dtype(dtype)}"
                f"|{normalized}")
    return hashlib.sha256(identity.encode("utf-8")).hexdigest()[:32]


def compute_fingerprint(fields: dict) -> str:
    """sha256 over canonical JSON (sorted keys, compact separators)."""
    canonical = json.dumps(fields, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def normalize_dtype(dtype: str) -> str:
    """Canonical dtype string: strip the ``torch.`` prefix so every layer
    (cache_key, store defense, manifest) sees the same spelling —
    ``str(torch.bfloat16)`` and tensor-meta dtype must not diverge."""
    return str(dtype).removeprefix("torch.")


def normalize_model_identity(model: str) -> str:
    """Reduce a checkpoint path/id to its stable final segment.

    Production platforms hand each instance a random temp copy dir
    (``/tmp/model_temp_copy_<rand>/<id>``); hashing the raw path splits
    the fingerprint across E/PD for the identical checkpoint. One rule
    covers every form — path, repo id, or bare name: take the last
    ``/``-separated segment.
    """
    if not model:
        return model
    return model.rstrip("/").rsplit("/", 1)[-1]


@dataclass
class StoreConfig:
    """Runtime store configuration (design 6.1).

    Priority: ec_connector_extra_config explicit key > environment
    variable > default — full-env deployment and per-service JSON tuning
    both work.
    """

    uri: str
    on_miss: str = "fail"
    upload_concurrency: int = 4
    upload_queue_size: int = 64
    memo_ttl: float = 300.0
    e_verify_store: bool = False

    @classmethod
    def from_env(cls, extra: dict | None = None) -> StoreConfig:
        extra = extra or {}

        def pick(key: str, env_name: str, default):
            if key in extra and extra[key] is not None:
                return extra[key]
            return os.getenv(env_name, default)

        uri = pick("artifact_uri", _ENV_URI, None)
        if not uri:
            raise ValueError(
                "VIT_ARTIFACT_URI is not set: the connector is activated "
                "but has no store destination (design 7.2)")
        on_miss = str(pick("on_miss", _ENV_ON_MISS, "fail"))
        if on_miss not in VALID_ON_MISS:
            raise ValueError(
                f"invalid on_miss {on_miss!r}, expected one of {VALID_ON_MISS}")
        return cls(
            uri=str(uri),
            on_miss=on_miss,
            upload_concurrency=int(
                pick("upload_concurrency", _ENV_UPLOAD_CONCURRENCY, 4)),
            upload_queue_size=int(
                pick("upload_queue_size", _ENV_UPLOAD_QUEUE_SIZE, 64)),
            memo_ttl=float(pick("memo_ttl", _ENV_MEMO_TTL, 300.0)),
            e_verify_store=_env_bool(
                pick("e_verify_store", _ENV_E_VERIFY_STORE, "0")),
        )
