"""Exception family for the artifact store protocol."""
from __future__ import annotations


class ArtifactStoreError(RuntimeError):
    """Base class for artifact store failures."""


class ArtifactMissError(ArtifactStoreError):
    """Requested artifact is absent/incompatible: miss semantics (design 7.4)."""

    def __init__(self, reason: str):
        self.reason = reason
        super().__init__(reason)


class ArtifactCorruptError(ArtifactStoreError):
    """Stored object exists but fails integrity checks."""


class ArtifactFingerprintMismatchError(ArtifactCorruptError):
    """Manifest fingerprint does not match the consuming instance."""
