"""Manifest data model: tensor metadata, chunk table, validation.

Design §4.4: format_version=1; v1 single chunk single object, the chunks
array stays for forward compatibility.
"""
from __future__ import annotations

import json
from dataclasses import MISSING, asdict, dataclass, fields

FORMAT_VERSION = 1
_DTYPE_BYTES = {"bfloat16": 2, "float16": 2, "float32": 4}


@dataclass(frozen=True)
class TensorMeta:
    dtype: str
    hidden_size: int
    num_mm_tokens: int

    @property
    def dtype_bytes(self) -> int:
        try:
            return _DTYPE_BYTES[self.dtype]
        except KeyError:
            raise ValueError(f"unsupported dtype {self.dtype!r}") from None

    @property
    def expected_bytes(self) -> int:
        return self.num_mm_tokens * self.hidden_size * self.dtype_bytes


@dataclass(frozen=True)
class ChunkMeta:
    chunk_id: int
    num_tokens: int
    length: int
    checksum: str   # "sha256:<hex>" — the CAS object key (design 4.3)
    locator: str


@dataclass(frozen=True)
class Manifest:
    mm_hash: str
    model: str
    dtype: str
    hidden_size: int
    num_mm_tokens: int
    attempt_id: str
    created_at: str
    format_version: int = FORMAT_VERSION
    lora_name: str | None = None
    query_fingerprint: str | None = None
    etag: str | None = None
    source_url: str | None = None
    # ViT grid [t,h,w] patch units. E records it so PD's synth placeholder
    # can be forward-constructed (H=t*h*patch) at the exact same grid —
    # NEVER reverse-guess from num_mm_tokens (aspect ratio drives mrope).
    grid_thw: tuple[int, ...] | None = None
    chunks: tuple[ChunkMeta, ...] = ()

    def validate(self, current_format_version: int = FORMAT_VERSION) -> None:
        if self.format_version != current_format_version:
            raise ValueError(
                f"format_version {self.format_version} != {current_format_version}")
        ids = [c.chunk_id for c in self.chunks]
        if ids != list(range(len(self.chunks))):
            raise ValueError(f"chunk_id must be contiguous 0..N-1, got {ids}")
        if sum(c.num_tokens for c in self.chunks) != self.num_mm_tokens:
            raise ValueError("sum(chunks.num_tokens) != num_mm_tokens")
        meta = TensorMeta(self.dtype, self.hidden_size, self.num_mm_tokens)
        if sum(c.length for c in self.chunks) != meta.expected_bytes:
            raise ValueError(
                "sum(chunks.length) != num_mm_tokens*hidden_size*dtype_bytes")

    def to_json_bytes(self) -> bytes:
        return json.dumps(asdict(self), separators=(",", ":")).encode("utf-8")

    @classmethod
    def from_json_bytes(cls, data: bytes) -> Manifest:
        try:
            d = json.loads(data)
        except json.JSONDecodeError as e:
            raise ValueError(f"manifest is not valid JSON: {e}") from e
        if not isinstance(d, dict):
            raise TypeError("manifest must be a JSON object")
        # Fields with a default may be absent in older manifests (grid_thw
        # pre-0.2.3): tolerated and filled with their default; fields without
        # a default are required and must all be present.
        optional, required = [], []
        for f in fields(cls):
            (optional if f.default is not MISSING
             and f.default_factory is MISSING else required).append(f.name)
        missing = set(required) - set(d)
        if missing:
            raise ValueError(f"manifest missing fields: {sorted(missing)}")
        for name in optional:
            d.setdefault(name, None)
        try:
            d["chunks"] = tuple(ChunkMeta(**c) for c in d["chunks"])
            # JSON list -> tuple; old manifests predate the field and stay None
            if d.get("grid_thw") is not None:
                d["grid_thw"] = tuple(d["grid_thw"])
            return cls(**d)
        except (TypeError, ValueError) as e:
            raise ValueError(f"manifest schema error: {e}") from e
