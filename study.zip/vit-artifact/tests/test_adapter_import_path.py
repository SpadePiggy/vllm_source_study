"""Import-path tests for the vllm adapter subpackage (no vllm needed).

Regression for the 0.1.1 bug: ``vit_artifact.adapters.vllm`` lost its
``ECArtifactConnector`` export, so the documented factory path
``ec_connector_module_path=vit_artifact.adapters.vllm`` raised
AttributeError in production (deployments worked around it by pointing
at the submodule ``...artifact_connector`` directly).
"""
import importlib

import pytest


def test_package_has_lazy_export_attribute():
    import vit_artifact.adapters.vllm as pkg

    assert "ECArtifactConnector" in pkg.__all__


def test_lazy_getattr_raises_outside_vllm():
    # Without vllm installed, the lazy import must raise ModuleNotFoundError
    # (NOT AttributeError from the package itself) — the PEP 562 __getattr__
    # contract: unknown names raise AttributeError, known names attempt
    # the real import.
    import vit_artifact.adapters.vllm as pkg

    with pytest.raises(ModuleNotFoundError):
        _ = pkg.ECArtifactConnector


def test_unknown_attribute_still_attributeerror():
    import vit_artifact.adapters.vllm as pkg

    with pytest.raises(AttributeError, match="NoSuchName"):
        _ = pkg.NoSuchName


def test_factory_module_path_resolution_with_stubbed_vllm(monkeypatch):
    # Simulate the factory's exact two steps with vllm importable:
    # importlib.import_module(path) + getattr(module, "ECArtifactConnector")
    import sys
    import types

    # Stub the vllm modules the connector imports at module load.
    fake_vllm = types.ModuleType("vllm")
    base_mod = types.ModuleType("vllm.distributed.ec_transfer.ec_connector.base")

    class _FakeBase:  # ECConnectorBase stand-in
        def __init__(self, *a, **k):
            pass

    class _FakeMeta:  # ECConnectorMetadata stand-in
        pass

    import enum

    class _FakeRole(enum.Enum):  # ECConnectorRole stand-in
        SCHEDULER = 0
        WORKER = 1

    base_mod.ECConnectorBase = _FakeBase
    base_mod.ECConnectorMetadata = _FakeMeta
    base_mod.ECConnectorRole = _FakeRole
    base_mod.ECArtifactMissError = type("ECArtifactMissError", (RuntimeError,), {})

    dist_mod = types.ModuleType("vllm.distributed")
    ec_pkg = types.ModuleType("vllm.distributed.ec_transfer")
    ec_conn_pkg = types.ModuleType("vllm.distributed.ec_transfer.ec_connector")

    monkeypatch.setitem(sys.modules, "vllm", fake_vllm)
    monkeypatch.setitem(sys.modules, "vllm.distributed", dist_mod)
    monkeypatch.setitem(sys.modules, "vllm.distributed.ec_transfer", ec_pkg)
    monkeypatch.setitem(
        sys.modules, "vllm.distributed.ec_transfer.ec_connector", ec_conn_pkg)
    monkeypatch.setitem(
        sys.modules, "vllm.distributed.ec_transfer.ec_connector.base", base_mod)

    # Drop cached adapter modules so the connector module re-executes
    # its `from vllm...` imports against the stubs.
    for mod in list(sys.modules):
        if mod.startswith("vit_artifact.adapters.vllm"):
            monkeypatch.delitem(sys.modules, mod)

    module = importlib.import_module("vit_artifact.adapters.vllm")
    cls = module.ECArtifactConnector  # factory does getattr(module, name)
    assert cls.__name__ == "ECArtifactConnector"
