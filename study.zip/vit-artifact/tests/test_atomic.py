"""Protocol tests against an in-memory fake backend (design §11.1).

Every backend inherits the same guarantees from the base class, so the
full commit protocol matrix runs once here.
"""
import hashlib
import json

import pytest

from vit_artifact import ArtifactCorruptError, ArtifactFingerprintMismatchError
from vit_artifact.atomic import EncoderArtifactStore
from vit_artifact.manifest import ChunkMeta, Manifest, TensorMeta

MODEL = "b47304eff23e11ce1004c862df4f340f"
FP = MODEL  # legacy alias for downstream test imports
MM = "a" * 32
META = TensorMeta("bfloat16", 3584, 4096)
CHUNK_BYTES = b"x" * META.expected_bytes  # v1 单 chunk 单对象


class InMemoryStore(EncoderArtifactStore):
    def __init__(self, root="/mem", model=MODEL, dtype=META.dtype):
        self.objects: dict[str, bytes] = {}
        super().__init__(root, model, dtype)

    def _put(self, key, data):
        self.objects[key] = data

    def _get(self, key):
        if key not in self.objects:
            raise KeyError(key)
        return self.objects[key]

    def _delete(self, key):
        self.objects.pop(key, None)

    def _list_prefix(self, prefix):
        return sorted(k for k in self.objects if k.startswith(prefix))


def commit_one(store, mm_hash=MM, chunk_bytes=CHUNK_BYTES, **mf_overrides) -> Manifest:
    att = store.begin_attempt({"mm_hash": mm_hash, "tensor_meta": META})
    checksum = "sha256:" + hashlib.sha256(chunk_bytes).hexdigest()
    store.write_chunk({"attempt_id": att, "chunk_id": 0}, chunk_bytes)
    assert att  # recorded in manifest below
    base = {
        "mm_hash": mm_hash, "model": MODEL, "dtype": META.dtype,
        "hidden_size": META.hidden_size, "num_mm_tokens": META.num_mm_tokens,
        "attempt_id": att, "created_at": "2026-09-08T00:00:00Z",
        "source_url": "bucket/p.png",
        "chunks": (ChunkMeta(0, META.num_mm_tokens, len(chunk_bytes), checksum,
                             f"{store.root}/{mm_hash}/chunks/{checksum[7:]}"),),
    }
    base.update(mf_overrides)
    m = Manifest(**base)
    store.commit(m)
    return m


class TestHappyPath:
    def test_commit_then_has_and_get(self):
        s = InMemoryStore()
        m = commit_one(s)
        assert s.has(MM) is True
        got = s.get_ready_manifest(MM)
        assert got == m
        assert s.open_chunk(m.chunks[0].locator) == CHUNK_BYTES

    def test_miss_returns_none(self):
        s = InMemoryStore()
        assert s.has("b" * 32) is False
        assert s.get_ready_manifest("b" * 32) is None


class TestInvisibility:
    def test_chunks_without_success_invisible(self):
        s = InMemoryStore()
        att = s.begin_attempt({"mm_hash": MM, "tensor_meta": META})
        s.write_chunk({"attempt_id": att, "chunk_id": 0}, CHUNK_BYTES)
        assert s.has(MM) is False  # 崩溃残留 = 不可见孤儿（铁律 ②③）


class TestCorruption:
    def test_success_digest_mismatch_is_corrupt(self):
        s = InMemoryStore()
        commit_one(s)
        key = next(k for k in s.objects if k.endswith("_SUCCESS"))
        payload = json.loads(s.objects[key])
        payload["digest"] = "sha256:" + "0" * 64
        s.objects[key] = json.dumps(payload).encode()
        with pytest.raises(ArtifactCorruptError):
            s.get_ready_manifest(MM)

    def test_bad_success_json_is_corrupt(self):
        s = InMemoryStore()
        commit_one(s)
        key = next(k for k in s.objects if k.endswith("_SUCCESS"))
        s.objects[key] = b"{broken"
        with pytest.raises(ArtifactCorruptError):
            s.get_ready_manifest(MM)

    def test_model_mismatch_raises(self):
        s = InMemoryStore()
        commit_one(s, model="another-model")
        with pytest.raises(ArtifactFingerprintMismatchError):
            s.get_ready_manifest(MM)


class TestCommitCrossCheck:
    def test_commit_with_unwritten_chunk_rejected(self):
        s = InMemoryStore()
        att = s.begin_attempt({"mm_hash": MM, "tensor_meta": META})
        m = Manifest(
            mm_hash=MM, model=MODEL, dtype=META.dtype, hidden_size=META.hidden_size,
            num_mm_tokens=META.num_mm_tokens, attempt_id=att, created_at="t",
            chunks=(ChunkMeta(0, META.num_mm_tokens, META.expected_bytes,
                              "sha256:" + "d" * 64, "chunks/d"),))
        with pytest.raises(ValueError, match="chunk"):
            s.commit(m)

    def test_commit_unknown_attempt_rejected(self):
        s = InMemoryStore()
        m = Manifest(mm_hash=MM, model=MODEL, dtype=META.dtype,
                     hidden_size=META.hidden_size, num_mm_tokens=META.num_mm_tokens,
                     attempt_id="nope", created_at="t")
        with pytest.raises(ValueError, match="attempt"):
            s.commit(m)


class TestConcurrentWriters:
    def test_last_writer_wins_both_readable(self):
        s = InMemoryStore()
        m1 = commit_one(s, chunk_bytes=b"a" * META.expected_bytes)
        m2 = commit_one(s, chunk_bytes=b"b" * META.expected_bytes)
        got = s.get_ready_manifest(MM)
        assert got == m2          # last-writer-wins
        assert got != m1
        # 旧版本 chunk 仍可读（不可变，铁律 ①）
        assert s.open_chunk(m1.chunks[0].locator) == b"a" * META.expected_bytes


class TestExpire:
    def test_expire_removes_visibility(self):
        s = InMemoryStore()
        commit_one(s)
        s.expire(MM)
        assert s.has(MM) is False

    def test_expire_wrong_version_noop(self):
        s = InMemoryStore()
        commit_one(s)
        s.expire(MM, version="sha256:" + "0" * 64)  # 版本不符：不删
        assert s.has(MM) is True


class TestIdentityPeek:
    """check_identity=False (0.2.4): the PD synth placeholder's grid
    lookup runs in the frontend process, which has no engine config —
    the store it opens carries empty model/dtype. The read must still
    succeed for METADATA while the default path stays defended."""

    def test_peek_reads_grid_across_identity(self):
        s = InMemoryStore()
        commit_one(s, grid_thw=(1, 4, 4))

        stranger = InMemoryStore(model="", dtype="")
        stranger.objects = s.objects  # same bytes, empty identity

        with pytest.raises(ArtifactFingerprintMismatchError):
            stranger.get_ready_manifest(MM)  # default: defended
        m = stranger.get_ready_manifest(MM, check_identity=False)
        assert m is not None and m.grid_thw == (1, 4, 4)

    def test_peek_still_rejects_corruption(self):
        s = InMemoryStore()
        commit_one(s)
        stranger = InMemoryStore(model="", dtype="")
        stranger.objects = s.objects
        key = s._success_key(MM)
        stranger.objects[key] = b"{corrupted"
        with pytest.raises(ArtifactCorruptError):
            stranger.get_ready_manifest(MM, check_identity=False)
