from tests.test_atomic import commit_one
from vit_artifact.cli import main, wait_ready


class TestWaitReady:
    def test_ready_when_expect_met(self, tmp_path):
        from vit_artifact import open_store
        s = open_store(f"file://{tmp_path}/vit")
        commit_one(s)
        ready, dirs = wait_ready(f"file://{tmp_path}/vit", expect=1, timeout=0.1)
        assert ready is True and len(dirs) >= 1

    def test_not_ready_times_out(self, tmp_path):
        ready, dirs = wait_ready(f"file://{tmp_path}/vit", expect=5,
                                 timeout=0.1, interval=0.01)
        assert ready is False and dirs == []

    def test_main_exit_codes(self, tmp_path, capsys):
        from vit_artifact import open_store
        s = open_store(f"file://{tmp_path}/vit")
        commit_one(s)
        rc = main(["wait-ready", "--uri", f"file://{tmp_path}/vit",
                   "--expect", "1", "--timeout", "1"])
        assert rc == 0
        rc = main(["wait-ready", "--uri", f"file://{tmp_path}/vit",
                   "--expect", "99", "--timeout", "0.1",
                   "--interval", "0.01"])
        assert rc == 2
        assert "TIMEOUT" in capsys.readouterr().err

    def test_main_bad_args(self):
        assert main(["wait-ready"]) == 1
