
import pytest

from vit_artifact import (
    ArtifactMissError,
    StoreConfig,
    cache_key,
    compute_fingerprint,
    mm_hash_from_url,
    normalize_dtype,
    normalize_model_identity,
    normalize_url,
)


class TestNormalizeUrl:
    def test_https_presigned_strips_query_and_endpoint(self):
        url = ("https://bahamutruntime.oss-cn-zhangjiakou.aliyuncs.com"
               "/vision_cache/a.png?x-oss-credential=X&x-oss-signature=Y")
        assert normalize_url(url) == "bahamutruntime/vision_cache/a.png|lora=|qfp="

    def test_oss_scheme_same_key_as_https(self):
        # 重签/换 scheme/换 endpoint 归一同键（设计 §5.2.2 承重点）
        a = normalize_url("https://b.oss-cn-zhangjiakou.aliyuncs.com/p/x.png?sig=1")
        b = normalize_url("oss://b/p/x.png")
        c = normalize_url("https://b.oss-cn-beijing-internal.aliyuncs.com/p/x.png?sig=2")
        assert a == b == c == "b/p/x.png|lora=|qfp="

    def test_lora_and_query_enter_key(self):
        base = "https://b.oss-x.aliyuncs.com/p/a.png"
        assert normalize_url(base, lora_name="l1") != normalize_url(base)
        assert normalize_url(base, query_fp="q1") != normalize_url(base, query_fp="q2")

    def test_non_http_url_passthrough(self):
        assert normalize_url("file:///tmp/x.jpg") == "file:///tmp/x.jpg|lora=|qfp="
        assert normalize_url("data:image/png;base64,AAA") == "data:image/png;base64,AAA|lora=|qfp="


class TestMmHash:
    def test_128bit_hex(self):
        h = mm_hash_from_url("https://b.oss-x.aliyuncs.com/p/a.png")
        assert len(h) == 32 and int(h, 16) >= 0

    def test_deterministic_and_signature_insensitive(self):
        a = mm_hash_from_url("https://b.e.com/p/a.png?x-oss-signature=OLD")
        b = mm_hash_from_url("https://b.e.com/p/a.png?x-oss-signature=NEW")
        assert a == b


class TestFingerprint:
    def test_canonical_and_stable(self):
        assert compute_fingerprint({"b": 1, "a": "x"}) == compute_fingerprint({"a": "x", "b": 1})

    def test_field_sensitive(self):
        assert compute_fingerprint({"dtype": "bfloat16"}) != compute_fingerprint({"dtype": "float16"})


class TestStoreConfig:
    def test_extra_over_env_over_default(self, monkeypatch):
        monkeypatch.setenv("VIT_ARTIFACT_URI", "file:///tmp/a")
        monkeypatch.setenv("VIT_ARTIFACT_ON_MISS", "recompute")
        cfg = StoreConfig.from_env({"artifact_uri": "file:///tmp/b", "on_miss": "fail"})
        assert cfg.uri == "file:///tmp/b" and cfg.on_miss == "fail"
        cfg2 = StoreConfig.from_env()
        assert cfg2.uri == "file:///tmp/a" and cfg2.on_miss == "recompute"

    def test_default_on_miss_is_fail(self, monkeypatch):
        monkeypatch.setenv("VIT_ARTIFACT_URI", "file:///tmp/a")
        monkeypatch.delenv("VIT_ARTIFACT_ON_MISS", raising=False)
        assert StoreConfig.from_env().on_miss == "fail"  # 默认（设计 D8）

    def test_missing_uri_raises(self, monkeypatch):
        monkeypatch.delenv("VIT_ARTIFACT_URI", raising=False)
        with pytest.raises(ValueError, match="VIT_ARTIFACT_URI"):
            StoreConfig.from_env()

    def test_invalid_on_miss_raises(self, monkeypatch):
        monkeypatch.setenv("VIT_ARTIFACT_URI", "file:///tmp/a")
        with pytest.raises(ValueError, match="on_miss"):
            StoreConfig.from_env({"on_miss": "explode"})

    def test_e_verify_store_default_off(self, monkeypatch):
        monkeypatch.setenv("VIT_ARTIFACT_URI", "file:///tmp/a")
        monkeypatch.delenv("VIT_ARTIFACT_E_VERIFY_STORE", raising=False)
        assert StoreConfig.from_env().e_verify_store is False

    def test_e_verify_store_env_and_extra(self, monkeypatch):
        monkeypatch.setenv("VIT_ARTIFACT_URI", "file:///tmp/a")
        monkeypatch.setenv("VIT_ARTIFACT_E_VERIFY_STORE", "1")
        assert StoreConfig.from_env().e_verify_store is True
        monkeypatch.setenv("VIT_ARTIFACT_E_VERIFY_STORE", "true")
        assert StoreConfig.from_env().e_verify_store is True
        monkeypatch.setenv("VIT_ARTIFACT_E_VERIFY_STORE", "0")
        cfg = StoreConfig.from_env({"e_verify_store": "1"})
        assert cfg.e_verify_store is True  # extra 覆盖 env
        assert StoreConfig.from_env().e_verify_store is False


def test_miss_error_carries_reason():
    e = ArtifactMissError("MISS_NO_MARKER")
    assert e.reason == "MISS_NO_MARKER"


class TestNormalizeModelIdentity:
    """0.1.2 fix: platform temp-copy dirs must not split E/PD fingerprints."""

    def test_random_temp_copy_prefix_stripped(self):
        # 生产事故形态：同模型、不同实例的随机临时目录 → 必须归一
        a = normalize_model_identity(
            "/tmp/model_temp_copy_0gvpyi4m/b47304eff23e11ce1004c862df4f340f")
        b = normalize_model_identity(
            "/tmp/model_temp_copy_n5spkjie/b47304eff23e11ce1004c862df4f340f")
        assert a == b == "b47304eff23e11ce1004c862df4f340f"

    def test_hf_repo_id_takes_last_segment(self):
        # 统一规则：repo id 也取末段（单一规则，无路径/repo-id 歧义分支）
        assert normalize_model_identity("Qwen/Qwen3-VL-32B-Instruct") == \
            "Qwen3-VL-32B-Instruct"

    def test_local_dir_takes_last_segment(self):
        assert normalize_model_identity("/models/qwen3-vl") == "qwen3-vl"

    def test_trailing_slash_and_empty(self):
        assert normalize_model_identity("/models/qwen3-vl/") == "qwen3-vl"
        assert normalize_model_identity("") == ""


class TestCacheKey:
    """Single-layer key (0.2): h128(model, URL, dtype) — key carries identity."""

    URL = "https://bahamutruntime.oss-cn-zhangjiakou.aliyuncs.com/vision_cache/a.png"
    MODEL = "/tmp/model_temp_copy_0gvpyi4m/b47304eff23e11ce1004c862df4f340f"

    def test_same_model_url_dtype_same_key(self):
        # E/PD 同模型（不同临时目录前缀）+ 同 URL + 同 dtype → 同键（命中根基）
        e = cache_key(self.URL, self.MODEL, "bfloat16")
        pd = cache_key(self.URL,
                       "/tmp/model_temp_copy_n5spkjie/b47304eff23e11ce1004c862df4f340f",
                       "bfloat16")
        assert e == pd and len(e) == 32

    def test_different_model_different_key(self):
        a = cache_key(self.URL, "model-a", "bfloat16")
        b = cache_key(self.URL, "model-b", "bfloat16")
        assert a != b

    def test_different_dtype_different_key(self):
        # dtype 防线：E 换 fp16 重编码 → 不同键 → 不会静默命中旧 bf16 数据
        a = cache_key(self.URL, self.MODEL, "bfloat16")
        b = cache_key(self.URL, self.MODEL, "float16")
        assert a != b

    def test_resigned_url_same_key(self):
        # 签名参数变化（重签）→ 同键
        a = cache_key(self.URL + "?x-oss-signature=OLD", self.MODEL, "bfloat16")
        b = cache_key(self.URL + "?x-oss-signature=NEW", self.MODEL, "bfloat16")
        assert a == b

    def test_normalize_dtype_strips_torch_prefix(self):
        # 全链口径归一：str(torch.bfloat16) 与 'bfloat16' 同源
        assert normalize_dtype("torch.bfloat16") == "bfloat16"
        assert cache_key(self.URL, self.MODEL, "torch.bfloat16") == \
            cache_key(self.URL, self.MODEL, "bfloat16")
