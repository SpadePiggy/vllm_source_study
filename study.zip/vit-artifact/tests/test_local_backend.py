import os

import pytest

from tests.test_atomic import FP, META, commit_one
from vit_artifact import open_store


class TestOpenStore:
    def test_file_scheme_returns_local(self, tmp_path):
        s = open_store(f"file://{tmp_path}/vit", model=FP, dtype=META.dtype)
        assert s.__class__.__name__ == "LocalStore"

    def test_oss_without_extra_raises_helpful(self):
        # 子进程验证（与主进程模块缓存完全隔离）：屏蔽 oss2 后调 open_store
        import subprocess
        import sys
        code = (
            "import sys; sys.modules['oss2']=None\n"  # None = 导入失败
            "from vit_artifact import open_store\n"
            "try:\n"
            "    open_store('oss://bucket/ns', 'f'*64)\n"
            "    raise SystemExit('should have raised')\n"
            "except ValueError as e:\n"
            "    assert 'vit-artifact[oss]' in str(e), e\n"
            "    raise SystemExit(0)\n"
        )
        r = subprocess.run([sys.executable, "-c", code],
                           capture_output=True, text=True, check=False,
                           env={"PYTHONPATH": "src", "PATH": "/usr/bin:/bin"})
        assert r.returncode == 0, (r.stdout, r.stderr)

    def test_skeleton_backends_not_implemented(self):
        for scheme in ("paimon", "holo", "igraph"):
            with pytest.raises(NotImplementedError):
                open_store(f"{scheme}://x")

    def test_unknown_scheme(self):
        with pytest.raises(ValueError, match="scheme"):
            open_store("ftp://x", FP)


class TestLocalStoreFidelity:
    def test_roundtrip_via_open_store(self, tmp_path):
        s = open_store(f"file://{tmp_path}/vit", model=FP, dtype=META.dtype)
        m = commit_one(s)
        assert s.has(m.mm_hash) is True
        assert s.open_chunk(m.chunks[0].locator) == b"x" * META.expected_bytes

    def test_get_missing_raises_keyerror(self, tmp_path):
        s = open_store(f"file://{tmp_path}/vit", model=FP, dtype=META.dtype)
        with pytest.raises(KeyError):
            s._get(f"{s.root}/no/such/key")

    def test_list_prefix(self, tmp_path):
        s = open_store(f"file://{tmp_path}/vit", model=FP, dtype=META.dtype)
        commit_one(s)
        keys = s._list_prefix(f"{s.root}/")
        assert any(k.endswith("_SUCCESS") for k in keys)

    def test_put_is_atomic_no_leftovers(self, tmp_path):
        s = open_store(f"file://{tmp_path}/vit", model=FP, dtype=META.dtype)
        s._put(f"{s.root}/k", b"v")
        vit = tmp_path.resolve() / "vit"
        assert (vit / "k").exists()
        # rename 后无 tmp 残留（mkstemp 前缀 tmpXXXX）
        assert not [p for p in os.listdir(vit) if p.startswith("tmp")]

    def test_key_escape_rejected(self, tmp_path):
        s = open_store(f"file://{tmp_path}/vit", model=FP, dtype=META.dtype)
        with pytest.raises(ValueError, match="escape"):
            s._path("/../../etc/passwd")
