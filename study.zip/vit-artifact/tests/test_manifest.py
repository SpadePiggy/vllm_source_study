import json

import pytest

from vit_artifact.manifest import ChunkMeta, Manifest, TensorMeta


def make_manifest(**overrides) -> Manifest:
    base = {
        "mm_hash": "a" * 32, "model": "b47304eff23e11ce1004c862df4f340f", "dtype": "bfloat16",
        "hidden_size": 3584, "num_mm_tokens": 4096, "attempt_id": "att-1",
        "created_at": "2026-09-08T00:00:00Z",
        "chunks": (ChunkMeta(chunk_id=0, num_tokens=4096, length=4096 * 3584 * 2,
                             checksum="sha256:" + "c" * 64,
                             locator="chunks/" + "c" * 64),),
    }
    base.update(overrides)
    return Manifest(**base)


class TestTensorMeta:
    def test_dtype_bytes_and_expected_bytes(self):
        m = TensorMeta("bfloat16", 3584, 4096)
        assert m.dtype_bytes == 2 and m.expected_bytes == 4096 * 3584 * 2

    def test_unknown_dtype_raises(self):
        meta = TensorMeta("int8", 8, 1)
        with pytest.raises(ValueError, match="dtype"):
            _ = meta.dtype_bytes


class TestValidate:
    def test_valid_passes(self):
        make_manifest().validate()

    def test_format_version_mismatch(self):
        m = make_manifest(format_version=2)
        with pytest.raises(ValueError, match="format_version"):
            m.validate(current_format_version=1)

    def test_chunk_ids_must_be_contiguous(self):
        bad = make_manifest(chunks=(
            ChunkMeta(1, 2048, 2048 * 3584 * 2, "sha256:" + "a" * 64, "chunks/a"),
            ChunkMeta(0, 2048, 2048 * 3584 * 2, "sha256:" + "b" * 64, "chunks/b"),
        ))
        with pytest.raises(ValueError, match="chunk_id"):
            bad.validate()

    def test_token_sum_mismatch(self):
        with pytest.raises(ValueError, match="num_tokens"):
            make_manifest(num_mm_tokens=8192).validate()

    def test_byte_sum_mismatch(self):
        with pytest.raises(ValueError, match="length"):
            make_manifest(chunks=(ChunkMeta(
                0, 4096, 123, "sha256:" + "c" * 64, "chunks/c"),)).validate()


class TestRoundtrip:
    def test_json_roundtrip(self):
        m = make_manifest(etag="etag-1", source_url="bucket/p.png", lora_name=None)
        m2 = Manifest.from_json_bytes(m.to_json_bytes())
        assert m2 == m

    def test_bad_json_raises_valueerror_not_keyerror(self):
        with pytest.raises(ValueError):
            Manifest.from_json_bytes(b"{not json")
        with pytest.raises(ValueError):
            Manifest.from_json_bytes(json.dumps({"unexpected": 1}).encode())

    def test_missing_field_raises_valueerror(self):
        d = json.loads(make_manifest().to_json_bytes())
        del d["mm_hash"]
        with pytest.raises(ValueError, match="mm_hash"):
            Manifest.from_json_bytes(json.dumps(d).encode())


class TestGridThw:
    """0.2.3: grid recorded by E, consumed by PD's synth placeholder."""

    def test_roundtrip_with_grid(self):
        m = make_manifest(grid_thw=(1, 8, 16))
        m2 = Manifest.from_json_bytes(m.to_json_bytes())
        assert m2.grid_thw == (1, 8, 16)

    def test_old_manifest_without_grid_stays_none(self):
        # 旧 manifest（无此字段）→ 读为 None（向后兼容），不报错
        d = json.loads(make_manifest().to_json_bytes())
        d.pop("grid_thw", None)
        m = Manifest.from_json_bytes(json.dumps(d).encode())
        assert m.grid_thw is None

    def test_validate_untouched_by_grid(self):
        make_manifest(grid_thw=(1, 8, 16)).validate()
        make_manifest(grid_thw=None).validate()
