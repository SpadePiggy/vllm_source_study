import pytest

from tests.test_atomic import FP, META, MM, commit_one

oss2 = pytest.importorskip("oss2")  # 无 oss2 的环境整个文件 skip

from vit_artifact.backends.oss import OSSStore


class FakeObj:
    def __init__(self, data):
        self._d = data

    def read(self):
        return self._d


class FakeBucket:
    """oss2.Bucket 双行为子集：put/get/delete/NotFound。"""

    def __init__(self):
        self.objects: dict[str, bytes] = {}
        self.put_calls: list[str] = []

    def put_object(self, key, data):
        self.put_calls.append(key)
        self.objects[key] = data

    def get_object(self, key):
        if key not in self.objects:
            # oss2.exceptions.NotFound(status, headers, body, details)
            raise oss2.exceptions.NotFound(404, {"x-oss-request-id": "fake"}, None, {"Code": "NoSuchKey"})
        return FakeObj(self.objects[key])

    def delete_object(self, key):
        self.objects.pop(key, None)


class FakeObjectIterator:
    def __init__(self, bucket, prefix):
        self._keys = sorted(k for k in bucket.objects if k.startswith(prefix))

    def __iter__(self):
        return iter(type("O", (), {"key": k}) for k in self._keys)


def make_store(monkeypatch):
    monkeypatch.setenv("OSS_ENDPOINT", "oss-cn-zhangjiakou.aliyuncs.com")
    monkeypatch.setenv("OSS_ACCESS_KEY_ID", "ak")
    monkeypatch.setenv("OSS_ACCESS_KEY_SECRET", "sk")
    bucket = FakeBucket()
    import vit_artifact.backends.oss as oss_mod
    monkeypatch.setattr(oss_mod, "_build_bucket", lambda self: bucket)
    store = OSSStore("oss://bahamutruntime/vision_cache", FP, META.dtype)
    monkeypatch.setattr(store, "_ObjectIterator",
                        lambda b, prefix: FakeObjectIterator(b, prefix))
    return store, bucket


class TestOSSBackend:
    def test_roundtrip(self, monkeypatch):
        store, bucket = make_store(monkeypatch)
        m = commit_one(store)
        assert store.has(m.mm_hash) is True
        assert any(k.endswith("_SUCCESS") for k in bucket.objects)

    def test_1rtt_read_path(self, monkeypatch):
        # get_ready_manifest 只发 1 次 get（_SUCCESS 内嵌 manifest，设计 4.3）
        store, _bucket = make_store(monkeypatch)
        commit_one(store)
        store._get_calls = []
        orig_get = store._get

        def counting_get(key):
            store._get_calls.append(key)
            return orig_get(key)

        store._get = counting_get
        store.get_ready_manifest(MM)
        assert len(store._get_calls) == 1

    def test_404_fast_path_miss(self, monkeypatch):
        store, _bucket = make_store(monkeypatch)
        assert store.get_ready_manifest("b" * 32) is None

    def test_missing_credentials_raise(self, monkeypatch):
        for var in ("OSS_ENDPOINT", "OSS_ACCESS_KEY_ID", "OSS_ACCESS_KEY_SECRET"):
            monkeypatch.delenv(var, raising=False)
        with pytest.raises(ValueError, match="OSS_ENDPOINT|OSS_ACCESS"):
            OSSStore("oss://b/ns", FP, META.dtype)

    def test_bad_uri_shape(self):
        with pytest.raises(ValueError, match="oss://"):
            OSSStore("oss://nobucket", FP, META.dtype)

    def test_list_prefix(self, monkeypatch):
        store, _bucket = make_store(monkeypatch)
        commit_one(store)
        keys = store._list_prefix(f"{store.root}/")
        assert any("_SUCCESS" in k for k in keys)
