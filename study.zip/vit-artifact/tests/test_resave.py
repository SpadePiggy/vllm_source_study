"""E store-verify mode (VIT_ARTIFACT_E_VERIFY_STORE=1) end-to-end at the
connector level: L1 hit → _SUCCESS point-check → miss → resave via
connector metadata → worker re-upload.

vllm is not installed in CI, so the two modules artifact_connector.py
imports are stubbed in sys.modules — scoped via monkeypatch so they
never leak into other tests (the lazy-getattr regression test depends
on vllm being absent). The connector logic under test is entirely ours.
"""
import importlib
import sys
import types

import pytest

torch = pytest.importorskip("torch")

from tests.test_atomic import META, MODEL


@pytest.fixture
def connector_cls(monkeypatch):
    base = types.ModuleType("vllm.distributed.ec_transfer.ec_connector.base")

    class ECArtifactMissError(RuntimeError):
        reason = ""

        def __init__(self, reason=""):
            self.reason = reason or type(self).__name__
            super().__init__(self.reason)

    class ECConnectorBase:
        def __init__(self, vllm_config, role):
            ec = vllm_config.ec_transfer_config
            self._is_producer = ec.is_ec_producer
            self._is_consumer = ec.is_ec_consumer

        @property
        def is_producer(self):
            return self._is_producer

        @property
        def is_consumer(self):
            return self._is_consumer

        def bind_connector_metadata(self, metadata):
            self._connector_metadata = metadata

        def _get_connector_metadata(self):
            return self._connector_metadata

    class ECConnectorRole:
        SCHEDULER = 0
        WORKER = 1

    base.ECArtifactMissError = ECArtifactMissError
    base.ECConnectorBase = ECConnectorBase
    base.ECConnectorMetadata = type("ECConnectorMetadata", (), {})
    base.ECConnectorRole = ECConnectorRole

    monkeypatch.setitem(sys.modules, "vllm", types.ModuleType("vllm"))
    monkeypatch.setitem(
        sys.modules, "vllm.distributed", types.ModuleType("vllm.distributed"))
    monkeypatch.setitem(
        sys.modules, "vllm.distributed.ec_transfer",
        types.ModuleType("vllm.distributed.ec_transfer"))
    monkeypatch.setitem(
        sys.modules, "vllm.distributed.ec_transfer.ec_connector",
        types.ModuleType("vllm.distributed.ec_transfer.ec_connector"))
    monkeypatch.setitem(
        sys.modules, "vllm.distributed.ec_transfer.ec_connector.base", base)

    for mod in list(sys.modules):
        if mod.startswith("vit_artifact.adapters.vllm"):
            monkeypatch.delitem(sys.modules, mod)
    mod = importlib.import_module(
        "vit_artifact.adapters.vllm.artifact_connector")
    return mod.ECArtifactConnector


class _Cfg:
    def __init__(self, role, extra=None):
        class _EC:
            ec_connector_extra_config = extra
            is_ec_producer = role == "ec_producer"
            is_ec_consumer = role == "ec_consumer"
        class _Model:
            model = MODEL
            dtype = "bfloat16"
        class _Device:
            device = "cpu"
        self.ec_transfer_config = _EC()
        self.model_config = _Model()
        self.device_config = _Device()


class _Elem:
    def __init__(self, data):
        self.data = data


class _MMFeature:
    def __init__(self, identifier, grid=None):
        self.identifier = identifier
        self.data = ({"image_grid_thw": _Elem(grid)}
                     if grid is not None else None)


class _Request:
    def __init__(self, mm_features):
        self.mm_features = mm_features


def make_connector(connector_cls, tmp_path, monkeypatch,
                   role="ec_producer", verify="1"):
    monkeypatch.setenv("VIT_ARTIFACT_URI", f"file://{tmp_path}/store")
    monkeypatch.setenv("VIT_ARTIFACT_E_VERIFY_STORE", verify)
    return connector_cls(_Cfg(role), role="ignored-by-stub-base")


def make_tensor(fill=1):
    return torch.full((META.num_mm_tokens, META.hidden_size), fill,
                      dtype=torch.bfloat16)


MM = "5" * 32


class TestNoteL1Hit:
    def test_missing_artifact_schedules_resave_with_grid(
            self, connector_cls, tmp_path, monkeypatch):
        conn = make_connector(connector_cls, tmp_path, monkeypatch)
        req = _Request([_MMFeature(MM, grid=torch.tensor([1, 4, 4]))])
        conn.note_l1_hit(req, 0)
        assert MM in conn._resave
        assert conn._resave[MM] == (1, 4, 4)

    def test_present_artifact_no_resave(
            self, connector_cls, tmp_path, monkeypatch):
        from tests.test_atomic import commit_one
        conn = make_connector(connector_cls, tmp_path, monkeypatch)
        commit_one(conn._store, mm_hash=MM)
        conn.note_l1_hit(_Request([_MMFeature(MM)]), 0)
        assert conn._resave == {}

    def test_verify_off_is_noop(
            self, connector_cls, tmp_path, monkeypatch):
        conn = make_connector(connector_cls, tmp_path, monkeypatch, verify="0")
        conn.note_l1_hit(_Request([_MMFeature(MM)]), 0)
        assert conn._resave == {}
        assert conn._e_verify_store is False

    def test_consumer_gate(self, connector_cls, tmp_path, monkeypatch):
        conn = make_connector(connector_cls, tmp_path, monkeypatch,
                              role="ec_consumer")
        conn.note_l1_hit(_Request([_MMFeature(MM)]), 0)
        assert conn._resave == {}


class TestResaveFlow:
    def test_metadata_carries_resave_then_worker_reuploads(
            self, connector_cls, tmp_path, monkeypatch):
        conn = make_connector(connector_cls, tmp_path, monkeypatch)
        req = _Request([_MMFeature(MM, grid=[2, 8, 8])])
        conn.note_l1_hit(req, 0)

        class _Out:
            pass
        meta = conn.build_connector_meta(_Out())
        assert meta.resave == {MM: (2, 8, 8)}
        assert conn._resave == {}  # drained — 下一步不重发

        # worker side: L1-resident tensor + save_caches(grid_thw=...)
        encoder_cache = {MM: make_tensor()}
        conn.save_caches(encoder_cache=encoder_cache, mm_hash=MM,
                         grid_thw=meta.resave[MM])
        assert conn._uploader.drain(timeout=5) is True
        assert conn._uploader.counters["committed"] == 1
        m = conn._store.get_ready_manifest(MM)
        assert m is not None and m.grid_thw == (2, 8, 8)

    def test_pointcheck_error_degrades_to_missing(
            self, connector_cls, tmp_path, monkeypatch):
        conn = make_connector(connector_cls, tmp_path, monkeypatch)

        def exploding_get(mm_hash):
            raise OSError("oss down")

        conn._store.get_ready_manifest = exploding_get
        conn.note_l1_hit(_Request([_MMFeature(MM)]), 0)
        assert MM in conn._resave  # 查询失败按缺失处理 → 触发补传


class TestExternalLoadSeam:
    """Regression (PD pod crash, 0.2.3): build_connector_meta shipped
    _pending.items() pairs while worker_io unpacks (mm_hash, num_tokens,
    manifest) triples — the first external load raised ValueError inside
    execute_model and killed the engine. This is the missing seam test:
    real connector metadata fed into the real worker_io loader."""

    def test_metadata_feeds_worker_io_roundtrip(
            self, connector_cls, tmp_path, monkeypatch):
        from tests.test_atomic import META, commit_one
        from vit_artifact.adapters.vllm.worker_io import load_into_encoder_cache

        monkeypatch.setenv("VIT_ARTIFACT_URI", f"file://{tmp_path}/store")
        conn = connector_cls(_Cfg("ec_consumer"), role="ignored-by-stub")
        commit_one(conn._store, mm_hash=MM, grid_thw=(1, 4, 4))

        assert conn.has_cache_item(MM, num_embeds=META.num_mm_tokens) is True
        conn.update_state_after_alloc(_Request([_MMFeature(MM)]), 0)

        meta = conn.build_connector_meta(None)
        assert len(meta.items[0]) == 3  # triple contract
        conn.bind_connector_metadata(meta)

        encoder_cache: dict = {}
        load_into_encoder_cache(conn, encoder_cache)
        t = encoder_cache[MM]
        assert t.shape == (META.num_mm_tokens, META.hidden_size)
        assert t.dtype == torch.bfloat16

    def test_manifest_still_defended_on_has_cache_item(
            self, connector_cls, tmp_path, monkeypatch):
        from tests.test_atomic import commit_one

        monkeypatch.setenv("VIT_ARTIFACT_URI", f"file://{tmp_path}/store")
        # connector identity differs from the artifact's writer identity
        conn = connector_cls(_Cfg("ec_consumer"), role="ignored-by-stub")
        commit_one(conn._store, mm_hash=MM, model="another-model")

        base = sys.modules["vllm.distributed.ec_transfer.ec_connector.base"]
        with pytest.raises(base.ECArtifactMissError) as ei:
            conn.has_cache_item(MM, num_embeds=1)  # on_miss=fail → 请求级响亮 miss
        assert "another-model" in ei.value.reason  # 防线原因可见
