import threading

import pytest

from tests.test_atomic import META, commit_one

torch = pytest.importorskip("torch")

from vit_artifact.adapters.vllm.uploader import Uploader

MM = "a" * 32


MODEL = "b47304eff23e11ce1004c862df4f340f"
DTYPE = "bfloat16"


def make_store(tmp_path):
    from vit_artifact import open_store
    return open_store(f"file://{tmp_path}/vit", model=MODEL, dtype=DTYPE)


def fake_encoder_cache(mm_hash=MM, fill=b"\x01"):
    t = torch.full((META.num_mm_tokens, META.hidden_size), 0,
                   dtype=torch.bfloat16)
    raw = t.view(torch.uint8).numpy()
    raw[:] = int.from_bytes(fill[:1], "big")
    return {mm_hash: t}


class TestUploader:
    def test_commit_makes_artifact_ready(self, tmp_path):
        store = make_store(tmp_path)
        u = Uploader(store, concurrency=2, queue_size=8, model=MODEL, dtype=DTYPE)
        u.enqueue(fake_encoder_cache(), MM)
        assert u.drain(timeout=5) is True
        assert store.has(MM) is True
        assert u.counters["committed"] == 1

    def test_dedup_after_commit(self, tmp_path):
        store = make_store(tmp_path)
        u = Uploader(store, concurrency=2, queue_size=8, model=MODEL, dtype=DTYPE)
        u.enqueue(fake_encoder_cache(), MM)
        u.drain(timeout=5)
        u.enqueue(fake_encoder_cache(), MM)  # committed 后重入 → reused
        assert u.counters["reused"] == 1
        assert u.drain(timeout=5) is True

    def test_restart_dedup_via_store_has(self, tmp_path):
        store = make_store(tmp_path)
        commit_one(store, mm_hash=MM)  # 上一进程已传
        u = Uploader(store, concurrency=2, queue_size=8, model=MODEL, dtype=DTYPE)
        u.enqueue(fake_encoder_cache(), MM)
        u.drain(timeout=5)
        assert u.counters["skipped"] == 1
        assert u.counters["committed"] == 0

    def test_failure_does_not_mark_persisted(self, tmp_path, monkeypatch):
        store = make_store(tmp_path)

        def exploding_put(key, data):
            raise OSError("oss down")

        monkeypatch.setattr(store, "_put", exploding_put)
        u = Uploader(store, concurrency=1, queue_size=8, model=MODEL, dtype=DTYPE)
        u.enqueue(fake_encoder_cache(), MM)
        u.drain(timeout=5)
        assert u.counters["failed"] == 1
        assert MM not in u._persisted  # 同图重现可重试（A3）

    def test_queue_backpressure_no_loss(self, tmp_path):
        store = make_store(tmp_path)
        u = Uploader(store, concurrency=1, queue_size=1, model=MODEL, dtype=DTYPE)
        u.enqueue(fake_encoder_cache("b" * 32), "b" * 32)
        t = threading.Thread(
            target=lambda: u.enqueue(fake_encoder_cache("c" * 32), "c" * 32))
        t.start()
        t.join(timeout=10)  # 满队列阻塞=背压（A2）——不丢不溢出
        assert u.drain(timeout=5) is True
        assert store.has("b" * 32) and store.has("c" * 32)


class TestEVerifyStore:
    """VIT_ARTIFACT_E_VERIFY_STORE=1: uploader must not trust the
    in-process _persisted set — store.has() decides, so artifacts
    deleted out-of-band get re-uploaded.

    drain() is one-shot by design (shutdown semantics: it joins the
    worker threads), so these tests poll live workers instead — the
    resave path in production also runs on live threads."""

    def _wait_for(self, u, key, value, timeout=5.0):
        import time
        deadline = time.time() + timeout
        while time.time() < deadline and u.counters[key] < value:
            time.sleep(0.02)
        return u.counters[key]

    def test_verify_mode_reuploads_after_delete(self, tmp_path):
        import shutil
        store = make_store(tmp_path)
        u = Uploader(store, concurrency=1, queue_size=4, model=MODEL,
                     dtype=DTYPE, verify_store=True)
        u.enqueue(fake_encoder_cache(), MM)
        assert self._wait_for(u, "committed", 1) == 1
        shutil.rmtree(tmp_path / "vit" / MM)  # 背后删该键（ossutil rm 前缀，非桶根）
        u.enqueue(fake_encoder_cache(), MM)  # _persisted 拦不住
        assert self._wait_for(u, "committed", 2) == 2
        assert store.has(MM) is True

    def test_verify_off_keeps_reused_gate(self, tmp_path):
        import shutil
        store = make_store(tmp_path)
        u = Uploader(store, concurrency=1, queue_size=4, model=MODEL,
                     dtype=DTYPE)
        u.enqueue(fake_encoder_cache(), MM)
        assert self._wait_for(u, "committed", 1) == 1
        shutil.rmtree(tmp_path / "vit" / MM)
        u.enqueue(fake_encoder_cache(), MM)
        assert self._wait_for(u, "reused", 1) == 1
        assert u.counters["committed"] == 1
        assert store.has(MM) is False  # 默认形态：L1 记忆即真理（现状语义）


class TestGridThwPersist:
    """0.2.3: grid_thw flows from save_caches kwargs into the manifest."""

    def test_grid_recorded_in_manifest(self, tmp_path):
        from tests.test_atomic import MODEL
        store = make_store(tmp_path)
        u = Uploader(store, concurrency=1, queue_size=4,
                     model=MODEL, dtype=DTYPE)
        # enqueue 经由 save_caches 的 kwargs 通道（grid 以 tensor-like 可迭代进）
        u.enqueue(fake_encoder_cache(), MM, grid_thw=(1, 64, 64))
        assert u.drain(timeout=5) is True
        m = store.get_ready_manifest(MM)
        assert m is not None and m.grid_thw == (1, 64, 64)

    def test_grid_none_kept_none(self, tmp_path):
        from tests.test_atomic import MODEL
        store = make_store(tmp_path)
        u = Uploader(store, concurrency=1, queue_size=4,
                     model=MODEL, dtype=DTYPE)
        u.enqueue(fake_encoder_cache(), MM, grid_thw=None)
        assert u.drain(timeout=5) is True
        m = store.get_ready_manifest(MM)
        assert m is not None and m.grid_thw is None
