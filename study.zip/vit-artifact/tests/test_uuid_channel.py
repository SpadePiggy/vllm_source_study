"""URL→mm_hash channel: vLLM's native request-level ``uuid`` field.

Verified engine seam (zero fork changes for this task):
  chat_utils.py:1626  part.get("uuid") → mm_parser.parse_image(url, uuid)
  inputs.py:24-56     get_mm_hashes: uuid non-None → hash is derived from
                      the uuid (or used verbatim when no processor kwargs),
                      NOT from image bytes
  => E and PD sending the same ``uuid`` get the same mm_hash.

The DRIVER (orchestration, out of package scope per design §1) computes
uuid = mm_hash_from_url(url) via this package and puts it into the
image_url content part of BOTH E and PD requests.
"""

from vit_artifact import mm_hash_from_url


class TestUuidChannelContract:
    def test_same_url_same_uuid(self):
        # E 与 PD 对同一 URL（任意签名形态）算出同一 uuid → 引擎同一 mm_hash
        e = mm_hash_from_url("https://b.e.com/p/a.png?x-oss-signature=OLD")
        p = mm_hash_from_url("https://b.e.com/p/a.png?x-oss-signature=NEW")
        assert e == p and len(e) == 32

    def test_lora_changes_uuid(self):
        base = "https://b.e.com/p/a.png"
        assert mm_hash_from_url(base, lora_name="tower-lora") != mm_hash_from_url(base)

    def test_uuid_is_safe_json_string(self):
        h = mm_hash_from_url("https://b.e.com/p/a.png")
        assert h.isalnum() and h == h.lower()
