"""Patch-file sanity: applies cleanly to a pristine v0.17.1_omega tree.

Runs ``git apply --check`` in a throwaway worktree of the fork; no vllm
import needed (pure git/text assertions).
"""
import subprocess
from pathlib import Path

FORK = Path("/Users/lxt/Documents/AIOS/vllm")
PATCH = Path(__file__).resolve().parents[1] / "patches" / "vllm-v0.17.1_omega-ec-plugin.patch"


def _run(cmd, cwd=FORK):
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True,
                          check=False)


def test_patch_file_exists_and_nonempty():
    assert PATCH.is_file() and PATCH.stat().st_size > 100


def test_patch_applies_to_base_branch():
    wt = FORK.parent / ".patch-check-wt"
    if wt.exists():
        _run(["git", "worktree", "remove", "--force", str(wt)])
    r = _run(["git", "worktree", "add", str(wt), "v0.17.1_omega"])
    assert r.returncode == 0, r.stderr
    try:
        r = _run(["git", "apply", "--check", str(PATCH)], cwd=wt)
        assert r.returncode == 0, r.stderr
    finally:
        _run(["git", "worktree", "remove", "--force", str(wt)])


def test_patch_touches_expected_files():
    text = PATCH.read_text()
    for path in ("ec_connector/base.py", "core/sched/scheduler.py",
                 "example_connector.py", "chat_utils.py",
                 "vit_artifact_synth.py"):
        assert path in text
    assert "ECArtifactMissError" in text
    assert "num_embeds" in text
    assert "FINISHED_ERROR" in text
    assert "VLLM_VIT_SYNTH" in text
    assert "VIT_ARTIFACT_URL_KEY" in text    # E-side URL-key mode hunk
    assert "synth_placeholder" in text       # plan-C placeholder hunk
    assert "grid_thw" in text                # plan-C E-side grid recording
    assert "broadcast_object" in text        # rank0-pull + TP-broadcast hunk
    assert "_ec_load_via_rank0_broadcast" in text
    assert "note_l1_hit" in text             # E store-verify L1-hit hook
    assert "VIT_ARTIFACT_E_VERIFY_STORE" in text  # e-verify mode env var
    assert "resave" in text                  # worker resave-from-L1 hunk
    assert "check_identity=False" in text    # grid peek skips identity defense
