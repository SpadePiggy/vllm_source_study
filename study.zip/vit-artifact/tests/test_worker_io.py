import pytest

from tests.test_atomic import META, commit_one

torch = pytest.importorskip("torch")

from vit_artifact.adapters.vllm.worker_io import load_into_encoder_cache


class FakeMeta:
    def __init__(self, items):
        self.items = items


class FakeConnector:
    def __init__(self, store, items, device="cpu"):
        self._store = store
        self._meta = FakeMeta(items)
        self.device = device

    def _get_connector_metadata(self):
        return self._meta


class TestLoad:
    def test_load_into_encoder_cache(self, tmp_path):
        from vit_artifact import open_store
        store = open_store(f"file://{tmp_path}/vit")
        m = commit_one(store)
        conn = FakeConnector(store, [(m.mm_hash, m.num_mm_tokens, m)])
        cache: dict = {}
        load_into_encoder_cache(conn, cache)
        t = cache[m.mm_hash]
        assert t.shape == (m.num_mm_tokens, m.hidden_size)
        assert t.dtype == torch.bfloat16

    def test_existing_hash_skipped(self, tmp_path):
        from vit_artifact import open_store
        store = open_store(f"file://{tmp_path}/vit")
        m = commit_one(store)
        conn = FakeConnector(store, [(m.mm_hash, m.num_mm_tokens, m)])
        cache = {m.mm_hash: torch.zeros(1)}
        load_into_encoder_cache(conn, cache)
        assert cache[m.mm_hash].shape == (1,)  # 未被覆盖

    def test_checksum_failure_raises(self, tmp_path):
        from vit_artifact import open_store
        store = open_store(f"file://{tmp_path}/vit")
        m = commit_one(store)
        store._put(m.chunks[0].locator, b"corrupted-bytes")  # 静默腐坏模拟
        conn = FakeConnector(store, [(m.mm_hash, m.num_mm_tokens, m)])
        with pytest.raises(RuntimeError, match="checksum"):
            cache: dict = {}
            load_into_encoder_cache(conn, cache)

    def test_multi_hash_parallel(self, tmp_path):
        from vit_artifact import open_store
        store = open_store(f"file://{tmp_path}/vit")
        m1 = commit_one(store, mm_hash="a" * 32, chunk_bytes=b"a" * META.expected_bytes)
        m2 = commit_one(store, mm_hash="b" * 32, chunk_bytes=b"b" * META.expected_bytes)
        conn = FakeConnector(store, [
            (m1.mm_hash, m1.num_mm_tokens, m1),
            (m2.mm_hash, m2.num_mm_tokens, m2)])
        cache: dict = {}
        load_into_encoder_cache(conn, cache)
        assert set(cache) == {m1.mm_hash, m2.mm_hash}


class TestDeviceResolution:
    """Regression: the engine mixin passes no device, and the old
    getattr fallback put every loaded embedding on CPU — on GPU
    deployments the forward pass crashed on a cross-device tensor."""

    def test_connector_device_wins(self, tmp_path):
        # connector.device 显式设置 → 解析优先级第一（不真搬 tensor：CPU-only CI）
        from tests.test_atomic import META as ATOMIC_META
        from tests.test_atomic import MODEL
        from tests.test_atomic import commit_one as atomic_commit
        from vit_artifact import open_store
        from vit_artifact.adapters.vllm.worker_io import _resolve_device

        store = open_store(f"file://{tmp_path}/vit", model=MODEL,
                           dtype=ATOMIC_META.dtype)
        m = atomic_commit(store)
        conn = FakeConnector(store, [(m.mm_hash, m.num_mm_tokens, m)])
        conn.device = "cuda:1"
        assert _resolve_device(conn, {}) == "cuda:1"

    def test_kwargs_device_fallback(self, tmp_path):
        from tests.test_atomic import META as ATOMIC_META
        from tests.test_atomic import MODEL
        from tests.test_atomic import commit_one as atomic_commit
        from vit_artifact import open_store
        from vit_artifact.adapters.vllm.worker_io import _resolve_device

        store = open_store(f"file://{tmp_path}/vit", model=MODEL,
                           dtype=ATOMIC_META.dtype)
        m = atomic_commit(store)
        conn = FakeConnector(store, [(m.mm_hash, m.num_mm_tokens, m)])
        # FakeConnector 默认 device="cpu"；删掉后测 kwargs 与探测路径
        del conn.device

        assert _resolve_device(conn, {"device": "cuda:0"}) == "cuda:0"
        assert _resolve_device(conn, {}) == "cpu"  # 无 CUDA 测试机

    def test_explicit_device_on_connector(self):
        from vit_artifact.adapters.vllm.worker_io import _resolve_device

        class WithDevice:
            device = "cuda:3"

        assert _resolve_device(WithDevice(), {}) == "cuda:3"
